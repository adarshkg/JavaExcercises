package com.cg.demoonespring.dao;

import java.util.List;

import org.springframework.stereotype.Repository;

import com.cg.demoonespring.dto.Product;


public interface ProductDao {

	public void save(Product pro);
	public List<Product> showAll();
}
