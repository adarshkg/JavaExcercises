package com.cg.demoonespring.config;


import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;


@Configuration
@ComponentScan("com.cg.demoonespring")
public class JavaConfig {


	
	
	
	
//	@Bean(name="prod",autowire=Autowire.BY_TYPE)
//	public Product getProduct() {
//		Product pro = new Product();
//		pro.setId(1001);
//		pro.setName("ABCD");
//		pro.setPrice(555.11);
//		pro.setDescription("Good.");
//		return pro;
//	}
//	
//	@Bean(name="tran")
//
//	public Transaction getTransaction() {
//		Transaction t =new Transaction();
//		t.setId(10001);
//		t.setAmount(789.32);
//		t.setDescription("For Product One");
//		return t;
//	}
	
	
}
