
package com.cg.demoonespring.ui; 


import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import javax.annotation.PostConstruct;
import org.springframework.stereotype.Component;


import com.cg.demoonespring.config.JavaConfig;
import com.cg.demoonespring.dto.Product;
import com.cg.demoonespring.dto.Transaction;
import com.cg.demoonespring.service.ProductService;

@Component	
public class MyTest {

		private static ProductService productService;
		
		@Autowired
		private  ProductService service;
		
		@PostConstruct
	    private void init(){
			MyTest.productService =service;
	    }
	    
	public static void main(String[] args) {

//		ApplicationContext app = new ClassPathXmlApplicationContext("spring.xml");	
		
		AnnotationConfigApplicationContext app =new AnnotationConfigApplicationContext(JavaConfig.class);
		Product myProduct = (Product) app.getBean("product");
		
		Transaction myTransaction = (Transaction) app.getBean("tran");
		
		myProduct.setId(1001);
		myProduct.setName("ABCD");
		myProduct.setPrice(120.);
		myProduct.setDescription("Good");
		
		
		myTransaction.setId(10);
		myTransaction.setAmount(1234.5);
		myTransaction.setDescription("For Product 1001");
		
		
		
		productService.addProduct(myProduct);
		List<Product> products = productService.showAllProduct();
		
		for (Product product : products) {
			System.out.println("Id is "+product.getId());
			System.out.println("Name is "+product.getName());
			System.out.println("Price is "+product.getPrice());
			System.out.println("Description is "+product.getDescription());
			System.out.println("Transcation amount is"+product.getTran().getAmount());
			System.out.println("Transcation description is"+product.getTran().getDescription());
			System.out.println("Transcation amount is"+product.getTran().getAmount());
		}
//		myProduct.getAlldata();
//		
//		System.out.println(myProduct);
		//		Product p = (Product) app.getBean("prod");
//		
//		
//			public void getAlldata() {
//		System.out.println("ID is"+id);
//		System.out.println("name is"+name);
//		System.out.println("price is"+price);
//		System.out.println("description is"+description);
//		
//		
//		System.out.println("Id of Transaction is "+tran.getId());
//		System.out.println("Amount of Transaction is "+tran.getAmount());
//		System.out.println("Description of Transaction is"+tran.getDescription());
		
	
	
////		
//		p.getAlldata();
//		p.setId(101);
//		p.setName("asd");
//		p.setPrice(100);
//		p.setDescription("sony.....");
//		Product p2 = (Product) app.getBean("prod");		
//		
//		Item it = (Item) app.getBean("it");
//		it.getData();
	}

}
