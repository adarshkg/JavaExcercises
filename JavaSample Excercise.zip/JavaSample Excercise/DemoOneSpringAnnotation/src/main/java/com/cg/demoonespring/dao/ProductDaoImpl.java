package com.cg.demoonespring.dao;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Configurable;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Repository;

import com.cg.demoonespring.dto.Product;

@Repository("productdao")
@Scope("singleton")
public class ProductDaoImpl implements ProductDao {

	List<Product> productList = new ArrayList<Product>();

	
	public void save(Product pro) {
		
		productList.add(pro);
	}

	public List<Product> showAll() {

		return productList;
	}

}
