package com.cg.demoonespring.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Configurable;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Service;

import com.cg.demoonespring.dao.ProductDao;
import com.cg.demoonespring.dto.Product;

@Service("productService")

public class ProductserviceImpl implements ProductService {
	
	
	@Autowired	
//	@Qualifier(value="myproductdao")
	ProductDao productDao;
	
	public void addProduct(Product prod) {
		productDao.save(prod);
	}

	public List<Product> showAllProduct() {
		return productDao.showAll();
	}

}
