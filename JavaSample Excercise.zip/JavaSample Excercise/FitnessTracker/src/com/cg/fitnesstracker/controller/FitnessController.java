package com.cg.fitnesstracker.controller;

public class FitnessController {

}
