package com.cg.date;

import java.time.LocalDate;
import java.time.ZoneId;
import java.time.ZonedDateTime;

public class Test {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		LocalDate localDate = LocalDate.now();
		ZonedDateTime zone = ZonedDateTime.now(ZoneId.of("Australia/Sydney"));
		System.out.println(zone);//with zone 
		
		
		String str = new String();
//		System.out.println(localDate.now());//take 
//		System.out.println(localDate.plusDays(2));
//		System.out.println(localDate.isLeapYear());

 	}

}
