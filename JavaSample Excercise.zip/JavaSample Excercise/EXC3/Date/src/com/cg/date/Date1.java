
java.util.Date;
public class Date1 {
public static void main(String[]args)
{
	Date date = new Date();
	
}
}