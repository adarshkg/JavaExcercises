package com.cg.date;

public class FlighTime {

	public static void main(String[] args) {
		
		

	}

}
