package com.cg.date;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Scanner;
import java.util.StringTokenizer;

public class SampleDAte {

	public static void main(String[] args) throws ParseException {
		
		System.out.println("Enter date(yyyy/mm/dd)");
		Scanner scan = new Scanner(System.in);
		String str = scan.next();
		
		SimpleDateFormat format = new SimpleDateFormat("yyyy/mm/dd");
		Date givenDate = format.parse(str);
		System.out.println(givenDate.getDate());
	}

}
