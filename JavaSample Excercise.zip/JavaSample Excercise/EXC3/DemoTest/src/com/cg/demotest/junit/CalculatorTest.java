package com.cg.demotest.junit;

import static org.junit.jupiter.api.Assertions.*;


import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;

class CalculatorTest {
	int a;
	Calculator calc;
//	@BeforeAll
//	public static void beforeAll() {
//		System.out.println("Before All");
//	}
	
	
	@BeforeEach
	public void dobeforeMyTest() {
		calc=new Calculator();
//		System.out.println("Before test....");
	}
	
	
	@org.junit.jupiter.api.Test
	public void doMyTestOne() {
		assertEquals(12.0, calc.addNumber(10, 2));
//		System.out.println("In test1....");


   }
	@org.junit.jupiter.api.Test
	public void doMyTestTwo() {
		assertEquals(8.0, calc.subNumber(10, 2));
//		System.out.println("in test2....");

   }
	@org.junit.jupiter.api.Test
	public void doMyTestThree() {
		assertEquals(20.0, calc.mulNumber(10, 2));
//		System.out.println("in test3....");


   }
	@org.junit.jupiter.api.Test
	public void doMyTestFour() {
		assertEquals(5.0, calc.divNumber(10, 2));
//		System.out.println("in test4....");


   }
	
	@After
	public void doAfterMyTest() {
		calc =null;

	}
	
//	@AfterAll
//	public static void afterAll() {
//		System.out.println("After all....");
//
//	}
}
