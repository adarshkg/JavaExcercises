package com.cg.demotest.junit;

public class Calculator {

	public double addNumber(double num1, double num2){
		
		return num1+num2;
		
	}
	
	public double subNumber(double num1, double num2){
		return num1-num2;
		
	}
	
	public double mulNumber(double num1, double num2){
		return num1*num2;
		
	}
	
	public double divNumber(double num1, double num2){
		return num1/num2;
		
	}
}
