package com.cg.demostring.demo;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;

public class DemoString {

	public static void main(String[] args)  {
		// TODO Auto-generated method stub
//		String str = new String("Capgemini");
//		System.out.println(str.hashCode());
//		String str1 =new String("dfg");
//		System.out.println(str1.hashCode());
//		String	str1 ="hai";
//		System.out.println(str1.hashCode());
//		
//		System.out.println(str1.s);
	/*	StringBuffer stb = new StringBuffer();
		StringBuilder st =new StringBuilder();*/
		InputStream fileRead = null;
		OutputStream fileWrite = null;
		try {
			fileRead = new FileInputStream("D:\\myread.txt");
			fileWrite = new FileOutputStream("D:\\\\mywrite.txt");
			int data;
			while((data=fileRead.read())>=0)
			{
				
				fileWrite.write(data);
//				System.out.println(data);
//				char c= (char)data;
//				System.out.println(c);
			}
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			System.out.println("file not found");
		} catch (IOException e) {
			// TODO Auto-generated catch block
			System.out.println("File cant be read/open");
		}
		finally {
			try {
				fileRead.close();
				fileWrite.close();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				System.out.println("File not close");
			}
			
		}

	}

}
