package com.cg.demostring.ui;

import java.io.Serializable;

public class Employee  implements Serializable{
	
	int empId;
	String empNAme;
	double empSalary;
	
	
	public Employee(){
		
	}


	public Employee(int empId, String empNAme, double empSalary) {
		super();
		this.empId = empId;
		this.empNAme = empNAme;
		this.empSalary = empSalary;
	}


	public int getEmpId() {
		return empId;
	}


	public void setEmpId(int empId) {
		this.empId = empId;
	}


	public String getEmpNAme() {
		return empNAme;
	}


	public void setEmpNAme(String empNAme) {
		this.empNAme = empNAme;
	}


	public double getEmpSalary() {
		return empSalary;
	}


	public void setEmpSalary(double empSalary) {
		this.empSalary = empSalary;
	}
	
	@Override
	public String toString() {
		return "Employee [empId=" + empId + ", empNAme=" + empNAme + ", empSalary=" + empSalary + "]";
	}
}