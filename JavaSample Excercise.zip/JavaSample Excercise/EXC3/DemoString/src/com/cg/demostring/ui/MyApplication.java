package com.cg.demostring.ui;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.ObjectInput;
import java.io.ObjectInputStream;
import java.io.ObjectOutput;
import java.io.ObjectOutputStream;
import java.io.OutputStream;

public class MyApplication {
	public static void main(String[]args) {
		

		Employee emp =new Employee(1001,"Abcd",1000.0);
		
		
//		try {
//			InputStream fileread = new FileInputStream("myobject.txt");
//		} catch (FileNotFoundException e) {
//			// TODO Auto-generated catch block
//			e.printStackTrace();
//		}
		
		
		try {
			
			
			OutputStream fileWrite =  new FileOutputStream("D:\\myobject.txt");
			ObjectOutput objectWrite = new ObjectOutputStream(fileWrite);
			
			objectWrite.writeObject(emp);
			objectWrite.flush();
			objectWrite.close();	
			
			
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			System.out.println("file not found");
		} catch (IOException e) {
			// TODO Auto-generated catch block
			System.out.println("file not found");
		}
		
		
		
		
		InputStream fileRead;
		Employee empRead =null;
		try {
			fileRead = new FileInputStream("D:\\myobject.txt");
			ObjectInput objectRead = new ObjectInputStream(fileRead);
			empRead = (Employee)objectRead.readObject();
			objectRead.close();
			System.out.println(empRead);
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
	}
}
