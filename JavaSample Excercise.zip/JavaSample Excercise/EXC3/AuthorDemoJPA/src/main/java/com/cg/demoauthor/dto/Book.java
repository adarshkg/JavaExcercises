package com.cg.demoauthor.dto;

import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToMany;
import javax.persistence.OneToOne;

@Entity
public class Book {
	@Id
	private long ISBN;
	@Column(name = "book_title")
	private String title;
	@Column(name="book_price")
	private float price;
	@ManyToMany
	
	private List<Author> author;
	public Book(long iSBN, String title, float price, List<Author> author) {
		super();
		ISBN = iSBN;
		this.title = title;
		this.price = price;
		this.author = author;
	}
	public List<Author> getAuthor() {
		return author;
	}
	public void setAuthor(List<Author> author) {
		this.author = author;
	}
	@Override

	public String toString() {
		return "Book [ISBN=" + ISBN + ", title=" + title + ", price=" + price + "]";
	}
	public long getISBN() {
		return ISBN;
	}
	public void setISBN(long iSBN) {
		ISBN = iSBN;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public float getPrice() {
		return price;
	}
	public void setPrice(float price) {
		this.price = price;
	}
	public Book(long iSBN, String title, float price) {
		super();
		ISBN = iSBN;
		this.title = title;
		this.price = price;
	}
	public Book() {
		super();
	}

}
