package com.cg.demoauthor.ui;

import java.util.Scanner;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

import com.cg.demoauthor.dto.Author;
import com.cg.demoauthor.dto.Book;

public class MyAplication {

	public static void main(String[] args) {
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("demoauthor");
		EntityManager em = emf.createEntityManager();
		EntityTransaction tx = em.getTransaction();
		Scanner scan = new Scanner(System.in);
		Author author = new Author();
		Book book = new Book();
		System.out.println("1.Add author\n2.Update Author\n3.Remove Author\n");
		System.out.println("Enter your choice");
		int choice = scan.nextInt();
		
		switch (choice) {
		case 1:
			System.out.println("Enter the ID");
			int id = scan.nextInt();
			System.out.println("Enter the first name");
			String fname = scan.next();
			System.out.println("Enter the middle name");
			String mname = scan.next();
			System.out.println("Enter the last name");
			String lname =scan.next(); 
			System.out.println("Enter the phone number");
			long phoneNo = scan.nextLong();
			
			System.out.println("Enter the book_ID");
			int bk_id = scan.nextInt();
			System.out.println("Enter the title");
			String bk_name = scan.next();
			System.out.println("Enter the price");
			float price = scan.nextFloat();
			
			book.setISBN(bk_id);
			book.setPrice(price);
			book.setTitle(bk_name);
			
			author.setAuthorId(id);
			author.setFirstName(fname);
			author.setLastName(lname);
			author.setMiddleName(mname);
			author.setPhoneNo(phoneNo);
			
			tx.begin();
			em.persist(book);
			em.persist(author);
			tx.commit();
			break;
		case 2:
			System.out.println("Enter the ID");
			int id1 = scan.nextInt();
			

			
			author = em.find(Author.class, id1);
			if(author!=null)
			{
				System.out.println("Enter the ID");
				int id11 = scan.nextInt();
				System.out.println("Enter the first name");
				String fname1 = scan.next();
				System.out.println("Enter the middle name");
				String mname1 = scan.next();
				System.out.println("Enter the last name");
				String lname1 =scan.next(); 
				System.out.println("Enter the phone number");
				long phoneNo1 = scan.nextLong();
				
				author.setAuthorId(id1);
				author.setFirstName(fname1);
				author.setLastName(lname1);
				author.setMiddleName(mname1);
				author.setPhoneNo(phoneNo1);
					
			}
			break;
		case 3:
			System.out.println("Enter the ID");
			int id11 = scan.nextInt();
			tx.begin();
			author = em.find(Author.class, id11);	
			if(author!=null) {
				em.remove(author);
				tx.commit();
			}
			break;
		default:
			break;
		}
		
		
		
	}

}
