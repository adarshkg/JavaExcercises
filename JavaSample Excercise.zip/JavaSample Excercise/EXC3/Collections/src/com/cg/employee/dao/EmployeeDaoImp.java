package com.cg.employee.dao;

import java.util.ArrayList;
import java.util.List;

import com.cg.employee.pojo.Employee;

public class EmployeeDaoImp implements EmployeeDao{

	
	List<Employee> empData;
	
	
	public EmployeeDaoImp() {
	
             empData = new ArrayList<Employee>();
             
             
	}

	
	
	@Override
	public Employee save(Employee emp) {
		// TODO Auto-generated method stub
		
		empData.add(emp);
		return emp;
	}

	@Override
	public List<Employee> findByName(String name) {
		// TODO Auto-generated method stub
		
		return empData;
	}

	@Override
	public List<Employee> findById(int id) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<Employee> showAll() {
		// TODO Auto-generated method stub
		
		return empData;
	}

}
