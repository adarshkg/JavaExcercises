package com.cg.employee.service;

import java.util.List;

import com.cg.employee.dao.EmployeeDaoImp;
import com.cg.employee.pojo.Employee;

public class EmployeeService  implements IEmployeeService{

	EmployeeDaoImp dao;
	 public EmployeeService() {
		dao = new EmployeeDaoImp();
	}
	
	
	@Override
	public void addEmployee(Employee emp) {
		emp.setSalary(emp.getSalary()+emp.getSalary()*0.1);
		dao.save(emp);
	}

	@Override
	public List<Employee> searchByName(String name) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<Employee> showAll() {
		// TODO Auto-generated method stub
		return dao.showAll();
	}

	@Override
	public Employee update(int id) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void sort() {
		// TODO Auto-generated method stub
		
	}
			
}
