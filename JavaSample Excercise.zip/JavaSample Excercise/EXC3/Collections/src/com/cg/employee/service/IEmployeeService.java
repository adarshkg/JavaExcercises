package com.cg.employee.service;

import java.util.List;

import com.cg.employee.pojo.Employee;

public interface IEmployeeService {
	
	public void addEmployee(Employee emp);
	public List<Employee> searchByName(String name);
	public List<Employee> showAll();
	public Employee update(int id);
	public void sort();
}
