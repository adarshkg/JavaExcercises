package com.cg.employee.dao;

import java.util.List;

import com.cg.employee.pojo.Employee;

public interface EmployeeDao {
public Employee save(Employee emp);
public List<Employee> findByName(String name);
public List<Employee> findById(int id);
public List<Employee> showAll();

}
