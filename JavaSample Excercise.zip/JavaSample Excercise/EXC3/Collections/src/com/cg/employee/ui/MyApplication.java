package com.cg.employee.ui;

import java.security.Provider.Service;
import java.util.List;
import java.util.Scanner;

import com.cg.employee.pojo.Employee;
import com.cg.employee.service.EmployeeService;

public class MyApplication {
	
	static EmployeeService service;

	public MyApplication() {
		
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner scan = new Scanner(System.in);
		service =  new EmployeeService();
		int choice =0;
		do {
			printDetails();
			System.out.println("Enter the choice");
			choice = scan.nextInt();
			switch (choice) {
			case 1:
				System.out.println("Enter employee ID");
				int id = scan.nextInt();
				System.out.println("Enter employee NAme");
				String name = scan.next();
				System.out.println("Enter employee Salary");
				double salary = scan.nextDouble();
				
				
				//dto class
				Employee emp =  new Employee();
				emp.setId(id);
				emp.setName(name);
				emp.setSalary(salary);
				
				service.addEmployee(emp);
				
				break;
			case 2:
				
				List<Employee> myList = service.showAll();
				System.out.println(myList);
				for (Employee empData : myList)
				{
					
					System.out.println("Id is " +empData.getId());
					System.out.println("Name is " +empData.getName());
					System.out.println("Salary is " +empData.getSalary());
					
				}
				break;

			default:
				break;
			}
		}while(choice!=6);
		

	}
	public static void printDetails() {
		System.out.println("1.Add Employee");
		System.out.println("2.Show All Employee");
		System.out.println("3.Update Employee");
		System.out.println("4.Search Employee by Name");
		System.out.println("5.sort");
	}

}
