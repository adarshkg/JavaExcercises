package com.cg.assignment.ui;

import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.OutputStream;

public class MyAssignmentOne {

	public static void main(String[] args) {
		
		try {
			OutputStream fileWrite =  new FileOutputStream("D:\\salary.txt");
		} catch (FileNotFoundException e) {
	
			e.printStackTrace();
		}

	}

}
