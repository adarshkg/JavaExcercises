package com.cg.projectmanagement.ui;

import java.util.Scanner;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

import com.cg.projectmanagement.dto.Employee;
import com.cg.projectmanagement.dto.Project;

public class MyApplication {

	public static void main(String[] args) {
		
		EntityManagerFactory emf=Persistence.createEntityManagerFactory("demoprojectmanagement");
		EntityManager em = emf.createEntityManager();
		EntityTransaction tx= em.getTransaction();
		
		Scanner scan = new Scanner(System.in);
		Employee employee = new Employee();
		Project project = new Project();
		
		System.out.println("1.Add details\n2.Update Details\n3.Remove Details\n4.Find Emplyee By Projet Id");
		int choice = scan.nextInt();
		switch (choice) {
		
		case 1:
			System.out.println("Enter project id");
			int projId= scan.nextInt(); 
			System.out.println("Enter Project name");
			String projName = scan.next();
			project.setId(projId);
			project.setName(projName);		
			
			System.out.println("Enter Employee ID");
			int empId= scan.nextInt();
			System.out.println("Enter Employee Name");
			String name = scan.next();
			System.out.println("Enter Employee Salary");
			double salary = scan.nextDouble();
			
			employee.setId(empId);
			employee.setName(name);
			employee.setSalary(salary);
			employee.setProject(project);
			break;

		case 2:
			System.out.println("Enter Employee ID");
			int empId1= scan.nextInt();
			employee = em.find(Employee.class, empId1);
			if(employee!=null)
			{
			System.out.println("Enter Employee Name");
			String name1 = scan.next();
			System.out.println("Enter Employee Salary");
			double salary1 = scan.nextDouble();			
			
			System.out.println("Enter project id");
			int projId1= scan.nextInt();
			project = em.find(Project.class, projId1);
			System.out.println("Enter Project name");
			String projName1 = scan.next();
			project.setId(projId1);
			project.setName(projName1);
			
			employee.setId(empId1);
			employee.setName(name1);
			employee.setSalary(salary1);
			employee.setProject(project);
			}
			break;
		case 3:
			tx.begin();
			System.out.println("Enter Employee ID");
			int empId11= scan.nextInt();
			employee = em.find(Employee.class, empId11);
			if(employee!=null) {
				em.persist(employee);
				em.remove(employee);
				em.remove(employee.getProject());
				tx.commit();
			}
			break;
		default:
			break;
		}
		
		
		
		
	
		
		
		tx.begin();
		em.persist(project);
		em.persist(employee);
		tx.commit();

		

	}

}
