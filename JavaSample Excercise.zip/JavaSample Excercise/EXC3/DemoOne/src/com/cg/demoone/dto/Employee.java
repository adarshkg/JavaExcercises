package com.cg.demoone.dto;

public class Employee {
	
//	private int empId;

	private int empId;
	private String empName;
	private double empSalary;
//	private String empDeg;
//	private boolean bool;
//	private char ch;
	private Project proj;
	
    public Employee(int empId, String empName, double empSalary, Project proj) {
		super();
		this.empId = empId;
		this.empName = empName;
		this.empSalary = empSalary;
		this.proj = proj;
	}

	public Employee() {
		//System.out.println("In constructor.....");
		
	}
    
//    public Employee(int id, String name, float sal,boolean b,char c ) {
//		this.empId = id;
//		this.empName = name;
//		this.empSalary = sal;
//		this.bool = b;
//		this.ch = c;
//
//	}
//	
//	public void getlogin() {
////		int local;
//		System.out.println("in get login....\n int "+this.empId);
//		System.out.println("string "+this.empName);
//		System.out.println("float "+this.empSalary);
//		System.out.println("boolean "+this.bool);
//		System.out.println("character "+this.ch);
////		System.out.println(local);

	
//	}
	public void getlogout() {
		System.out.println("In get logout....");
		
	}
	
	
	

	public int getEmpId() {
		return empId;
	}

	public void setEmpId(int empId) {
		this.empId = empId;
	}

	public String getEmpName() {
		return empName;
	}

	public void setEmpName(String empName) {
		this.empName = empName;
	}

	public double getEmpSalary() {
		return empSalary;
	}

	public void setEmpSalary(double empSalary) {
		this.empSalary = empSalary;
	}

	public Project getProj() {
		return proj;
	}

	public void setProj(Project proj) {
		this.proj = proj;
	}

	@Override
	public String toString() {
		return "Employee [empId=" + empId + ", empName=" + empName + ", empSalary=" + empSalary + ", proj=" + proj
				+ "]";
	}

	

	
}
