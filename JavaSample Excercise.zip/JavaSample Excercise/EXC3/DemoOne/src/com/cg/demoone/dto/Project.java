package com.cg.demoone.dto;



public class Project {
	
	  private int projId;
	  private String projName;
	  private String projDesc;
	  private float projPrice;
	  
	  
	  public Project() {
		  
	  }
	  
	public Project(int projId, String projName, String projDesc, float projPrice) {
		super();
		this.projId = projId;
		this.projName = projName;
		this.projDesc = projDesc;
		this.projPrice = projPrice;
	}

	public int getProjId() {
		return projId;
	}
	
	public void setProjId(int projId) {
		this.projId = projId;
	}
	
	
	public String getProjName() {
		return projName;
	}
	
	public void setProjName(String projName) {
		this.projName = projName;
	}
	
	
	public String getProjDesc() {
		return projDesc;
	}
	
	
	public void setProjDesc(String projDesc) {
		this.projDesc = projDesc;
	}
	
	
	public float getProjPrice() {
		return projPrice;
	}
	
	
	public void setProjPrice(float projPrice) {
		this.projPrice = projPrice;
	}

	@Override
	public String toString() {
		return "Project [projId=" + projId + ", projName=" + projName + ", projDesc=" + projDesc + ", projPrice="
				+ projPrice + "]";
	}
	
	
	  
	  
	
	  }
	  
	  
	  

