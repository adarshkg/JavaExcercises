package com.cg.demoone.ui;
import java.util.Scanner;

import com.cg.demoone.dto.*;

public class MyApplication {
	public static void main(String [] args) {
		
	
		
	Employee emp = new Employee();
	Employee emp2 = new Employee();

	
	
	Project proj = new Project();
	Project proj2 = new Project();

	
	Scanner scr = new Scanner(System.in);
	System.out.println("enter the employee name");
	String name = scr.nextLine();
	System.out.println("enter the employee id");
	int id = scr.nextInt();
	
	System.out.println("enter the salary");
	double sal = scr.nextDouble();
	
	
	
	System.out.println("enter the project id");
	int projId = scr.nextInt();
	System.out.println("enter the project name");
	String projName = scr.next();
	System.out.println("Enter project Desc");
	String projDesc = scr.next();
	
//	int id = Integer.parseInt(args[0]);
//	String name = args[1];
//	int sal = Integer.parseInt(args[2]);
//	
//	int projId = Integer.parseInt(args[3]);
//	String projName = args[4];
//	String projDesc = args[5];
//	
	
	emp.setEmpId(id);
	emp.setEmpName(name);
	emp.setEmpSalary(sal);
	
	
	proj.setProjId(projId);
	proj.setProjName(projName);
	proj.setProjDesc(projDesc);
	
	
//	emp2.setEmpId(10002);
//	emp2.setEmpName("Sachin");
//	emp2.setEmpSalary(12312);
//	proj2.setProjId(1235);
//	proj2.setProjName("McDonalds");
//	proj2.setProjDesc("javascript-angularjs .....");


	
	
	emp.setProj(proj);
	emp2.setProj(proj2);
	
	
	
	
	System.out.println("project id is " +emp.getProj().getProjId());
	System.out.println("project name is  "+emp.getProj().getProjName());
	System.out.println("project description  "+emp.getProj().getProjDesc());
	
//	
//	System.out.println("\n\nproject id is " +emp2.getProj().getProjId());
//	System.out.println("project name is  "+emp2.getProj().getProjName());
//	System.out.println("project description  "+emp2.getProj().getProjDesc());
	

	
	emp.getlogout();
	}

}
