package com.cg.democollection.ui;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.TreeSet;

import com.cg.democollection.dto.Employee;

public class MyApplication {

	public static void main(String[] args) {
		
		System.out.println("Haii");
		A.getAll();
		
	}
}

class A {
	
public static void getAll() {
	System.out.println("Welcome");
}

}
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		//		Employee emp = new Employee(101,"A",101);
//		Employee emp2 = new Employee(102,"v",102);
//		Employee emp3 = new Employee(103,"b",100);
//		
//		
//		Set<String> my =new TreeSet<String>();
//		
//		Set<Employee> mySet = new HashSet<Employee>();
//		
//		mySet.add(emp);
//		mySet.add(emp2);
//		mySet.add(emp3);
////		System.out.println(mySet);
////		Collections.sort((List<Employee>)mySet);
//		
//		  List<Employee> list = new ArrayList<Employee>(mySet); 
//	      Collections.sort(list); 
//	      for (Employee employee : list) {
//			System.out.println(employee.getName());
//		}
//	      
//	      System.out.println(list);
//		
////		System.out.println(emp.hashCode()+" "+emp2.hashCode());
//		System.out.println(emp.equals(emp2));
//		
//		
////		
////		Set<String> myStr = new TreeSet<String>();
////		myStr.add("Y");
////		myStr.add("K");
////		myStr.add("L");
////		
////		myStr.add("A");
////		myStr.add("K");
//	
////		mySet.add("Y");
////		mySet.add("Y");
////		mySet.add("T");
////		mySet.add("K");
////		mySet.add("P");
//		System.out.println(mySet.size());
//		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
//		Employee tsr = new Employee(101,"asd",1000);
//		Employee tsr2 = new Employee(101,"asd",1000);
//		System.out.println(tsr.hashCode()+" "+tsr2.hashCode());
//		
//		
//		String str ="Capgemini";
//		String str1 ="Capgemini";
//		System.out.println(str.hashCode()+" "+str1.hashCode());
				

