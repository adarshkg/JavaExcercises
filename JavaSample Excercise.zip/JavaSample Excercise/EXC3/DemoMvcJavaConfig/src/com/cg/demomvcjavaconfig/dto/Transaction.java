package com.cg.demomvcjavaconfig.dto;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table(name="ProductTransaction")
public class Transaction {

	@Id
	private Integer id;
	
	@ManyToOne
	@JoinColumn(name="prod_tran")
	private Product prod;

	public Transaction() {
		super();
	}

	public Transaction(Integer id, Product prod) {
		super();
		this.id = id;
		this.prod = prod;
	}

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public Product getProd() {
		return prod;
	}

	public void setProd(Product prod) {
		this.prod = prod;
	}

	@Override
	public String toString() {
		return "Transaction [id=" + id + ", prod=" + prod + "]";
	}
	
	
	
}
