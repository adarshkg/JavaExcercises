package com.cg.demomvcjavaconfig.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;

import com.cg.demomvcjavaconfig.dto.Product;
import com.cg.demomvcjavaconfig.dto.Transaction;

@Repository
public class ProductDaoImpl implements ProductDao{

	@PersistenceContext
	EntityManager entitymanager;
	
	@Override
	public Product save(Product pro) {
		Product prodOne = getProduct(pro.getId());
		if(prodOne==null) {
		entitymanager.persist(pro);
		entitymanager.flush();
		}else {
			Transaction tran = new Transaction();
			tran.setId(pro.getTran().get(0).getId());
			tran.setProd(prodOne);
			entitymanager.persist(tran);
			entitymanager.flush();
		}
		return pro;
	}

	@Override
	public List<Product> show() {
		Query query = entitymanager.createQuery("FROM Product");
		List<Product> myList = query.getResultList();
		return myList;
	}

	public Product getProduct(Integer prodId) {
		Product prod=null;
		try {
		Query query = entitymanager.createQuery("FROM Product WHERE id=:prodId");
		query.setParameter("prodId", prodId);
		 prod =(Product) query.getSingleResult();
		}catch (Exception e) {
			System.out.println("No id found");
		}
		return prod;
		
	}
}
