package com.cg.demomvcjavaconfig.controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.cg.demomvcjavaconfig.dto.Product;
import com.cg.demomvcjavaconfig.dto.Transaction;
import com.cg.demomvcjavaconfig.service.ProductService;


@Controller
public class MyController {
	
	@Autowired
	ProductService productService;
	
	Product pr;
	
	@GetMapping("login")
	public String loginPage() {
		return "mylogin";
	}

	@PostMapping("checkLogin")
	public String doLogin(@RequestParam("uname") String user,
			@RequestParam("upass") String pass) {

		System.out.println("check login");
		if(user.equals("admin")&&pass.equals("123456")) {
			return "listpage";
		}else {
			return "error";
		}


	}

	@GetMapping("addpage")
	public ModelAndView getAddProduct(@ModelAttribute("prod") Product pro) {
		List <String> listofCategory = new ArrayList<>();
		listofCategory.add("Electronics");
		listofCategory.add("Grocery");
		listofCategory.add("Clothes");
		return new ModelAndView("addproduct","cato",listofCategory);

	}

	@PostMapping("addproduct")
	public  ModelAndView addProduct(@ModelAttribute("prod") Product prod) {
//		Product product = productService.addProduct(pro);
		this.pr=prod;
		return new ModelAndView("transaction");
	}
	@PostMapping("datatran")
	public ModelAndView addTransaction(@RequestParam("tran") int id) {
		Transaction tr =new Transaction();
		tr.setId(id);
		List<Transaction> tranList = new ArrayList<>();
		
		tranList.add(tr);
		Product prod = new Product();
		prod.setId(pr.getId());
		prod.setName(pr.getName());
		prod.setPrice(pr.getPrice());
		prod.setCategory(pr.getCategory());
		prod.setDescription(pr.getDescription());
		prod.setTran(tranList);
		Product product = productService.addProduct(prod);
		return new ModelAndView("success","key",product);
		
	}
	
	@GetMapping("showpage")
	public ModelAndView showProduct() {
		List <Product> myAllProduct = productService.showAll();
		return new ModelAndView("showall", "showproduct", myAllProduct);
	}
}
