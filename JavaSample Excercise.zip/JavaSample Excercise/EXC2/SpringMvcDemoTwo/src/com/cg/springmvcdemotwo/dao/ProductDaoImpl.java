package com.cg.springmvcdemotwo.dao;

import java.util.List;
import javax.persistence.Query ;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.springframework.stereotype.Repository;

import com.cg.springmvcdemotwo.dto.Product;

@Repository
public class ProductDaoImpl implements ProductDao{

	@PersistenceContext
	EntityManager entityManager; 
	
	@Override
	public Product save(Product pro) {
		entityManager.persist(pro);
		entityManager.flush();
		return null;
	}

	@Override
	public List<Product> show() {
		
		Query query = entityManager.createQuery("FROM Product");
		List<Product> myList =  query.getResultList();
		return myList;
	}

}
