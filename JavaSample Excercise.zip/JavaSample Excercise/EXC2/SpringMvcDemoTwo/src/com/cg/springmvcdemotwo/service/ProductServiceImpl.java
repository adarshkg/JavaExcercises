package com.cg.springmvcdemotwo.service;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.springmvcdemotwo.dao.ProductDao;
import com.cg.springmvcdemotwo.dto.Product;

@Service
@Transactional
public class ProductServiceImpl  implements ProductService{

	@Autowired
	ProductDao productdao;
	@Override
	public Product addProduct(Product pro) {
		return productdao.save(pro);
	}

	@Override
	public List<Product> showAll() {
		return productdao.show();
	}

}
