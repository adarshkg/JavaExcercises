package com.cg.testdatabase.ui;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.Scanner;

public class TestPreparedStatementDelete {

	public static void main(String[] args) throws SQLException {
		Connection conn = DBUtil.getConnection(DBType.MYSQLDB);
		
		String sql = "Delete from City where ID = ?";
		
		Scanner scan = new Scanner(System.in);
		System.out.println("Enter the ID");
		int ID = scan.nextInt();
	
		
		
		PreparedStatement pstmt = conn.prepareStatement(sql);

		pstmt.setInt(1, ID);
		
		int result = pstmt.executeUpdate();
		if(result==1) {
			System.out.println("Delted succesfully");
		}
		else
			 System.err.println("error in inserting");
		
		scan.close();
		pstmt.close();
		conn.close();

	}

}
