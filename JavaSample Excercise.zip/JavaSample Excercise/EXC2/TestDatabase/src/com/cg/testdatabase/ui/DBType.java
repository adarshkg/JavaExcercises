package com.cg.testdatabase.ui;

public enum DBType {
	ORADB,MYSQLDB;
}
