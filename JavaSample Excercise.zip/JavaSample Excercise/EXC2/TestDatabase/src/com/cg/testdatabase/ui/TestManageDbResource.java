package com.cg.testdatabase.ui;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class TestManageDbResource {
	
	
	
	public static void main(String[] args) throws SQLException {
		Connection conn = null;
		Statement st = null;
		ResultSet rs = null;
		
		try {
			conn = DBUtil.getConnection(DBType.MYSQLDB);
			st = conn.createStatement();
			rs = st.executeQuery("select * from country");
//			rs.last();
			String format = "%-30s%-30s%-35s%-20f\n";
			while(rs.next()) {
				System.out.format(format, rs.getString("Name"),rs.getString("Continent"),rs.getString("Region"),rs.getFloat("SurfaceArea"));
			}
			System.out.println("total rows "+rs.getRow());
		} catch (SQLException e) {

			System.err.println(e.getMessage());
		}finally {
			if(rs!=null)
				rs.close();
			if(st!=null)
				st.close();
			if(conn!=null)
				conn.close();
		}
	}

}
