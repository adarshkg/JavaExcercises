package com.cg.testdatabase.ui;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class ResultSetScrollingDemo {

	public static void main(String[] args) throws SQLException {
		try(
				Connection conn = DBUtil.getConnection(DBType.MYSQLDB);
				Statement stmt = conn.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE,ResultSet.CONCUR_READ_ONLY);
				ResultSet rs = stmt.executeQuery("select * from city where id<=10");
				
				){
			String format = "%-30s%-30s%-30s%-20f\n";
			rs.beforeFirst();
			System.out.println(" Data from first ten rows");
			
			while(rs.next()) {
				System.out.format(format, rs.getString("Name"),rs.getString("CountryCode"),rs.getString("District"),rs.getFloat(("Population")));
			}
			
			rs.afterLast();
			System.out.println("\nLast ten rows");
			
			while(rs.previous()) {
				System.out.format(format, rs.getString("Name"),rs.getString("CountryCode"),rs.getString("District"),rs.getFloat(("Population")));
			}
			
			
			rs.first();
			System.out.println("\nFirst row");
			System.out.format(format, rs.getString("Name"),rs.getString("CountryCode"),rs.getString("District"),rs.getFloat(("Population")));
		
			rs.last();
			System.out.println("\nLast row");
			System.out.format(format, rs.getString("Name"),rs.getString("CountryCode"),rs.getString("District"),rs.getFloat(("Population")));
		}
	}

}
