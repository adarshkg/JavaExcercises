package com.cg.testdatabase.ui;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class PreparedStatementRetrieveDemo {

	public static void main(String[] args) throws SQLException{
		Connection conn =null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;

		try {
			conn = DBUtil.getConnection(DBType.MYSQLDB);
			String sql = "select * from city where Population < ? and Name = ? ";
			pstmt = conn.prepareStatement(sql,ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_READ_ONLY);
			prepareStatement(pstmt,1000,"Kabul");
			System.out.println("------------------------------");
			prepareStatement(pstmt, 10000, "Willemstad");

		} catch (SQLException e) {
			e.getMessage();
		}

	}

	private static void prepareStatement(PreparedStatement pstmt,int Population,String Name) throws SQLException {
		ResultSet rs;
		pstmt.setInt(1, Population);
		pstmt.setString(2, Name);
		String format ="%-10s%-30s%-20s%-20s%-20f\n";

		rs =pstmt.executeQuery();

		while(rs.next()) {
			System.out.format(format, rs.getInt("ID"),rs.getString("Name"),rs.getString("CountryCode")
					,rs.getString("District"),rs.getFloat("Population"));
		}
		rs.last();
		System.out.println(rs.getRow());
	}

}
