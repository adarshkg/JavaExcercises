package com.cg.testdatabase.ui;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class DBUtil {

	private static final String MySQLUsername = "root";
	private static final String MySQLPassword = "Capgemini123";
	private static final String MySQLDbURL = "jdbc:mysql://localhost:3306/world";
	
	private static final String ORAUsername = "root";
	private static final String ORAPassword = "Capgemini123";
	private static final String ORADbURL = "jdbc:oracle:thin@localhost:1521:xe";
	public static Connection getConnection(DBType dbtype) throws SQLException {
		switch (dbtype) {
		case ORADB:
			return DriverManager.getConnection(ORADbURL, ORAUsername, ORAPassword);		
		case MYSQLDB:				
			
			return DriverManager.getConnection(MySQLDbURL, MySQLUsername, MySQLPassword);
		default:
			return null;
		}
	}
}
