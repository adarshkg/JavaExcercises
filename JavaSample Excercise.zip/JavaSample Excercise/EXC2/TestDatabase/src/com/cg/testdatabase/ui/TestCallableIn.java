package com.cg.testdatabase.ui;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.Scanner;

public class TestCallableIn {

	public static void main(String[] args) throws SQLException {
		Connection conn =  DBUtil.getConnection(DBType.MYSQLDB);
		
		int ID, Population;
		String Name;
		String CountryCode, District;
		
		
		Scanner scan = new Scanner(System.in);
		
		System.out.println("Enter the id");
		ID = scan.nextInt();
		
		
		System.out.println("Enter the Name of Place");
		Name = scan.next();
		
		System.out.println("Enter the CountryCode");
		CountryCode = scan.next();
		
		System.out.println("Enter the District");
		District = scan.next();
		
		System.out.println("Enter the Population");
		Population = scan.nextInt();
		
		
		
		CallableStatement callableStatement = conn.prepareCall("{call city(?,?,?,?,?)}");
		
		callableStatement.setInt(1, ID);
		callableStatement.setString(2, Name);
		callableStatement.setString(3, CountryCode);
		callableStatement.setString(4, District);
		callableStatement.setInt(5, Population);
		
		int result = callableStatement.executeUpdate();
		
		if(result==1)
		{
			System.out.println("Added succesfully");
		}
		else
			System.err.println("Error while adding the data");
		scan.close();
		callableStatement.close();
		conn.close();
		

	}

}
