package com.cg.testdatabase.ui;

public class DemoDB {

	public static void main(String[] args) {
	
	}

}
