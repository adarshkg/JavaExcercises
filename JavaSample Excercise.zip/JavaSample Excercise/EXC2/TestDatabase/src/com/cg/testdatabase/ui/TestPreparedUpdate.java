package com.cg.testdatabase.ui;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.Scanner;

public class TestPreparedUpdate {

	public static void main(String[] args) throws SQLException {
		Connection conn = DBUtil.getConnection(DBType.MYSQLDB);
		
		String sql = "Update City  set Population = ? where ID = ?";
		
		Scanner scan = new Scanner(System.in);
		System.out.println("Enter the ID");
		int ID = scan.nextInt();
		
		System.out.println("Enter the Population");
		int Population = scan.nextInt();
		
		
		PreparedStatement pstmt = conn.prepareStatement(sql);
		pstmt.setInt(1, Population);
		pstmt.setInt(2, ID);
		
		int result = pstmt.executeUpdate();
		if(result==1) {
			System.out.println("Inserted succesfully");
		}
		else
			 System.err.println("error in inserting");
		
		scan.close();
		pstmt.close();
		conn.close();
	}

}
