package com.cg.testdatabase.ui;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class ItearatingWithResourcesUsingTryWithResources {

	public static void main(String[] args) throws SQLException {
	
		
		try(	Connection conn = DBUtil.getConnection(DBType.MYSQLDB);
				Statement st = conn.createStatement();
				ResultSet rs = st.executeQuery("select * from country");) {
		
			String format = "%-30s%-30s%-35s%-20f\n";
			while(rs.next()) {
				System.out.format(format, rs.getString("Name"),rs.getString("Continent"),rs.getString("Region"),rs.getFloat("SurfaceArea"));
			}
			System.out.println("total rows "+rs.getRow());
		} catch (SQLException e) {

			System.err.println(e.getMessage());
		}

	}

}
