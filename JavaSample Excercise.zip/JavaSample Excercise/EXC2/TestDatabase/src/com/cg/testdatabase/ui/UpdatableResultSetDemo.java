package com.cg.testdatabase.ui;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class UpdatableResultSetDemo {

	public static void main(String[] args) throws SQLException {
		try(
			Connection conn = DBUtil.getConnection(DBType.MYSQLDB);
			Statement stmt = conn.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_UPDATABLE); 
			ResultSet rs = stmt.executeQuery("select * from city");
				)
		{
			rs.absolute(6);
			rs.updateString("Name", "Lahore");
			rs.updateRow();
			System.out.println("Record update succesfully");
			
//			rs.moveToInsertRow();
//			rs.updateString("Name", "Kabul1");
//			rs.updateString("CountryCode", "afg");
//			rs.updateString("District", "Kabul123");
//			rs.updateString("Population", "100");
//			
//			rs.insertRow();
			System.out.println("Record inserted succesfully");
		} catch (SQLException e) {
			System.out.println("error");
			
		}

	}

}
