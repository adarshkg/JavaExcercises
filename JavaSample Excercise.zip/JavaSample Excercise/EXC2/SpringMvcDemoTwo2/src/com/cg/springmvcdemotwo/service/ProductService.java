package com.cg.springmvcdemotwo.service;

import java.util.List;

import com.cg.springmvcdemotwo.dto.Product;

public interface ProductService {

	public Product addProduct(Product pro);
	public List<Product> showAll();
}
