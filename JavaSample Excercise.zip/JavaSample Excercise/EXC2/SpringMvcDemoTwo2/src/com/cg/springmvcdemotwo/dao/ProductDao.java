package com.cg.springmvcdemotwo.dao;

import java.util.List;

import com.cg.springmvcdemotwo.dto.Product;

public interface ProductDao {

	public Product save(Product pro);
	public List<Product> show();
}
