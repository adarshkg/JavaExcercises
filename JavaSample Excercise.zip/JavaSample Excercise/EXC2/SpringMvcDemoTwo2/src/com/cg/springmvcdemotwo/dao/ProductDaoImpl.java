package com.cg.springmvcdemotwo.dao;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Repository;

import com.cg.springmvcdemotwo.dto.Product;

@Repository
public class ProductDaoImpl implements ProductDao{

	List<Product> myList =  new ArrayList<>();
	@Override
	public Product save(Product pro) {
		myList.add(pro);
		return null;
	}

	@Override
	public List<Product> show() {
		return myList;
	}

}
