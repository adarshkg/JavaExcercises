package com.cg.tripreview.exceptions;

public class DestinationDetailNotFoundException extends Exception {

	public DestinationDetailNotFoundException() {
		super();

	}
	public DestinationDetailNotFoundException(String message) {
		super(message);

	}

}
