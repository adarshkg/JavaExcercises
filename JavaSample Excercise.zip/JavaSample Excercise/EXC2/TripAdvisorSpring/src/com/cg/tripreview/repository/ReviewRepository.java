package com.cg.tripreview.repository;

import com.cg.tripreview.dto.Review;

public interface ReviewRepository {
		public Review save(Review review);
		
}
