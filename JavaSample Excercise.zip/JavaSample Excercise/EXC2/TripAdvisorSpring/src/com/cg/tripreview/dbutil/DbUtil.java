package com.cg.tripreview.dbutil;

import java.util.ArrayList;
import java.util.List;

import com.cg.tripreview.dto.Destination;
import com.cg.tripreview.dto.Review;

public class DbUtil {
	public static List<Destination> destinationList = new ArrayList<>();
}
