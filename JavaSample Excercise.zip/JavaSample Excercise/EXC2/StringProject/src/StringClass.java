

public class StringClass {

	public static void main(String[] args) {
		String s = new String("hai");
		System.out.println(s.concat("ada"));

		
		StringBuffer sb = new StringBuffer();
	}

}
