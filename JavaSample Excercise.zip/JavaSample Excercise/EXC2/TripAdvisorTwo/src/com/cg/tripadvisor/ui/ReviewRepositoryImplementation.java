package com.cg.tripadvisor.ui;
/*package com.cg.tripadvisor.dao;

import java.util.ArrayList;
import java.util.List;

import com.cg.tripadvisor.dbutil.DbUtil;
import com.cg.tripadvisor.dto.Review;

public class ReviewRepositoryImplementation implements ReviewRepository {
	
	@Override
	public List<Review> save(Review review) {
		
		DbUtil.reviewData.add(review);
		System.out.println(DbUtil.reviewData);
		return DbUtil.reviewData;
		
		
		//System.out.println("In repo reveiew"+review);
		
		//System.out.println(DbUtil.reviewData);
		
		
	}


}
*/