package com.cg.tripadvisor.ui;


import java.util.List;

import com.cg.tripadvisor.dto.Review;

public interface ReviewRepository {
	public List<Review> save(Review review);
	

}
