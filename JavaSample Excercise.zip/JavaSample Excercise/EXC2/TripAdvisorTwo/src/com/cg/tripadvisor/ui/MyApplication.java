package com.cg.tripadvisor.ui;

import java.util.ArrayList;
import java.util.List;

import com.cg.tripadvisor.dbutil.DbUtil;
import com.cg.tripadvisor.dto.Destination;
import com.cg.tripadvisor.dto.Review;
import com.cg.tripadvisor.dto.Reviewer;
import com.cg.tripadvisor.service.DestinationServiceImplementation;
import com.cg.tripadvisor.service.ReviewServiceImplementation;

public class MyApplication {
	
	public static void main(String[] args) {

//		Declaring the variables needed for storing values
		
		int reviewId;
		String reviewCity;
		int reviewerId;
		int destinationRating;
		String reviewDescription;
		String reviewerMail;
		String reviewerName;
		String destinationCity;
		String destinationCountry;
		List<Review> reviewList =  new ArrayList<>();

		
//		Creating the object of service class
		
		DestinationServiceImplementation destinationService =new DestinationServiceImplementation();
    //	ReviewServiceImplementation reviewService =  new ReviewServiceImplementation();
		
    	
//    	Creating objects of dto class
    	
		Reviewer reviewerOne = new Reviewer();
		
		Destination destination = new Destination();
		Review reviewOne = new Review();
		
		
		
// 		Input the reviewer details and passing it to the dto class
		
		reviewerId =1000;
		reviewerName = "Tom";
		reviewerMail = "tom@gmail.com";
		
		reviewerOne.setId(reviewerId);
		reviewerOne.setName(reviewerName);
		reviewerOne.setEmail(reviewerMail);
		
		
	
		reviewId = 102;
		reviewCity ="Pune";
		reviewDescription = "First review for pune";
		
		reviewOne.setId(reviewerId);
		reviewOne.setDescription(reviewDescription);
		reviewOne.setReviewer(reviewerOne);
		reviewOne.setCity(reviewCity);
		reviewService.addReview(reviewOne);


//		Adding the another  review by the reviewer
		
		Reviewer reviewerTwo = new Reviewer();
		Review reviewTwo = new Review();
		
		reviewerId =1001;
		reviewerName = "John";
		reviewerMail = "john@gmail.com";

		reviewerTwo.setId(reviewerId);
		reviewerTwo.setName(reviewerName);
		reviewerTwo.setEmail(reviewerMail);

		reviewId =  102;
		reviewCity ="Pune";
		reviewDescription = "second review for pune";

		reviewTwo.setId(reviewerId);
		reviewTwo.setDescription(reviewDescription);
		reviewerTwo.setName(reviewCity);
		reviewTwo.setReviewer(reviewerTwo);

		reviewService.addReview(reviewTwo);
		//destinationService.addReviewToDestination(destinationName,reviewTwo);
		
		//service
		/*Destination destination= dao.findDestinationByName(destinationName);
		List<Review> reviews=destination.getReviewList();
		reviews.add(reviewTwo);
		destination.setReviewList(reviews);*/
		
		
//		input the destination details and passing to the dto class
		
		destinationCity = "Pune";
		destinationCountry = "India";
		destinationRating = 4;
		
		destination.setCity(destinationCity);
		destination.setCountry(destinationCountry);
		destination.setRating(destinationRating);
		destination.setReviewList(reviewList);
		
		destinationService.addDestination(destination);
//
////		-------------------------------------------Destination two and its reviews------------------------------------------------------------
//		
//		Reviewer reviewerThree = new Reviewer();
//		
//		Destination destinationTwo = new Destination();
//		Review reviewThree = new Review();
//// 		Input the reviewer details and passing it to the dto class
//		
//		reviewerId =1003;
//		reviewerName = "Barna";
//		reviewerMail = "barna@gmail.com";
//		
//		reviewerThree.setId(reviewerId);
//		reviewerThree.setName(reviewerName);
//		reviewerThree.setEmail(reviewerMail);
//		
//		
//	
//		reviewId = 103;
//		reviewCity = "Mumbai";
//		reviewDescription = "First review for Mumbai";
//		
//		reviewThree.setId(reviewerId);
//		reviewThree.setDescription(reviewDescription);
//		reviewThree.setCity(reviewCity);
//		reviewThree.setReviewer(reviewerThree);
//		
//		reviewService.addReview(reviewThree);
//
//
//		/*List<Review> reviews=new ArrayList<>();
//		reviews.add(new Review(176, "asbsjdgfhjdf", new Reviewer(1, "buntu", "buntu@gmail.com")));
//		new Destination("Mumbai", 3, "india", reviews);
//		reviewService.addReview(new Review(176, "asbsjdgfhjdf", new Reviewer(1, "buntu", "buntu@gmail.com")));
//		*/
//		
//		
////		Adding the another  review by the reviewer
//		
//		Reviewer reviewerFour = new Reviewer();
//		Review reviewFour = new Review();
//		
//		reviewerId =1004;
//		reviewerName = "Sachin";
//		reviewerMail = "sachin@gmail.com";
//
//		reviewerFour.setId(reviewerId);
//		reviewerFour.setName(reviewerName);
//		reviewerFour.setEmail(reviewerMail);
//
//		reviewId =  104;
//		reviewCity = "Mumbai";
//		reviewDescription = "second review for Mumbai";
//
//		reviewFour.setId(reviewerId);
//		reviewFour.setDescription(reviewDescription);
//		reviewFour.setCity(reviewCity);
//		reviewFour.setReviewer(reviewerFour);
//
//		reviewService.addReview(reviewFour);
//		
////		input the destination details and passing to the dto class
//	
//		destinationCity = "Mumbai";
//		destinationCountry = "India";
//		destinationRating = 4;
//		
//		destinationTwo.setCity(destinationCity);
//		destinationTwo.setCountry(destinationCountry);
//		destinationTwo.setRating(destinationRating);
//		destination.setReviewList(reviewList);
//		
//		destinationService.addDestination(destination);
//		
		
		
		
		
		
		
		
		
		
//		 displaying the reviews based on the destination name 
		
		List<Review> reviewListByCityName = destinationService.searchReviewByDestination("Pune");

		
		for (Review review2 : reviewListByCityName) {
			System.out.println("\nReview:"+review2.getDescription()+"\nReviewer Name:"+review2.getReviewer().getName());
		}
		
//		displaying the reviews based on the destination rating
		List<Destination> destinationListByRating = destinationService.searchDestinationByRating(4);
		for (Destination destination2 : destinationListByRating) {
			System.out.println("\nDestination with rating"+" "+destinationRating+" is "+destination2.getCity());
		}
				
	}
}


