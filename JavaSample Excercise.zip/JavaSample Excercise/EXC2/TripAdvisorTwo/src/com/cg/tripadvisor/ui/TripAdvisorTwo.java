package com.cg.tripadvisor.ui;

public class TripAdvisorTwo {

	public static void main(String[] args) {
	
		System.out.println("The main page");
		
	
	
}
}
