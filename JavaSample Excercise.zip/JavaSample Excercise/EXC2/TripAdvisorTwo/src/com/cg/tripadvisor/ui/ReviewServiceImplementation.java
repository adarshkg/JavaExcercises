package com.cg.tripadvisor.ui;
/*package com.cg.tripadvisor.service;

import java.util.ArrayList;
import java.util.List;

import com.cg.tripadvisor.dao.ReviewRepositoryImplementation;
import com.cg.tripadvisor.dbutil.DbUtil;
import com.cg.tripadvisor.dto.Review;

public class ReviewServiceImplementation implements ReviewService {
	
	
	ReviewRepositoryImplementation repo = new ReviewRepositoryImplementation();
	
	@Override
	public void addReview(Review review) {
		
		
		repo.save(review);		
	}
	
	@Override
	public List<Review> getReview() {
		
		return DbUtil.reviewData;
	}


}
*/