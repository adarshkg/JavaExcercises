package com.cg.tripadvisor.ui;

import java.util.List;

import com.cg.tripadvisor.dto.Review;

public interface ReviewService {
	public void addReview(Review review);

	public List<Review> getReview();
	
}
