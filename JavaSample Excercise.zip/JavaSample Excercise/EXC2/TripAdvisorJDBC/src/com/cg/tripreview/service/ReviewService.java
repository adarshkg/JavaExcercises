package com.cg.tripreview.service;

import com.cg.tripreview.dto.Review;
import com.cg.tripreview.exceptions.DestinationDetailNotFoundException;

public interface ReviewService {
	
	public Review addReview(Review review,String city) throws DestinationDetailNotFoundException;
	
}
