package com.cg.tripadvisor.dao;


import java.util.List;

import com.cg.tripadvisor.dto.Destination;
import com.cg.tripadvisor.dto.Review;

public interface DestinationRepository {
	public Destination save(Destination destination);
	public List<Destination> findDestinationByRating(int Rating);
	public Destination findDestinationByName(String city);
	
}
