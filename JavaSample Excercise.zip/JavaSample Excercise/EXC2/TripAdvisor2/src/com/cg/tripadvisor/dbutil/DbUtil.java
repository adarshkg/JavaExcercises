package com.cg.tripadvisor.dbutil;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.cg.tripadvisor.dto.Destination;
import com.cg.tripadvisor.dto.Review;

public class DbUtil {

	public static List<Destination> destinationData =  new ArrayList<>();	

}
