package com.cg.tripadvisor.dao;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import com.cg.tripadvisor.dbutil.DbUtil;
import com.cg.tripadvisor.dto.Destination;


public class DestinationRepositoryImplemenation implements DestinationRepository {

	@Override
	public Destination save(Destination destination) {
		Iterator<Destination> itr=DbUtil.destinationData.iterator();
		while(itr.hasNext()) {
			if(itr.next().getCity().equalsIgnoreCase((destination.getCity()))) {
				itr.remove();
			}
		}
		DbUtil.destinationData.add(destination);
		return destination;
	}

	@Override
	public List<Destination> findDestinationByRating(int rating) {
		List<Destination> destinationList = new ArrayList<>();
		for (Destination destination : DbUtil.destinationData ) {
			if(destination.getRating()==rating) { 
				destinationList.add(destination);
			}
		}
		return destinationList;
	}

	public Destination findDestinationByName(String city) {
		for (Destination destination : DbUtil.destinationData ) 
			if(destination.getCity().equalsIgnoreCase((city)))
				return destination;

		return null;
	}

}
