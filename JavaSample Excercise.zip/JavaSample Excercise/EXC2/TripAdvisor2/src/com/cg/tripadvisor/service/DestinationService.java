package com.cg.tripadvisor.service;

import java.util.List;

import com.cg.tripadvisor.dto.Destination;
import com.cg.tripadvisor.dto.Review;
import com.cg.tripadvisor.exceptions.DestinationNotFoundException;

public interface DestinationService {
	public Destination addReviewToDestination(Review review, String city) throws DestinationNotFoundException;
	public Destination addDestination(Destination destination);
	public List<Review> searchReviewByDestination(String city) throws DestinationNotFoundException;
	public List<Destination> searchDestinationByRating(int rating) throws DestinationNotFoundException;

	
}
