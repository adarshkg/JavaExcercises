package com.cg.tripadvisor.dto;

public class Review {
    private int id;
    private String description;
    String city;
    private Reviewer reviewer ;
	public Review() {
		super();
	}
	public Review(int id, String description, Reviewer reviewer) {
		super();
		this.id = id;
		this.description = description;
		this.reviewer = reviewer;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public Reviewer getReviewer() {
		return reviewer;
	}
	public void setReviewer(Reviewer reviewer) {
		this.reviewer = reviewer;
	}
	@Override
	public String toString() {
		return "\n Review \n id=" + id + ",\n Description=" + description + ",\n reviewer=" + reviewer + "]";
	}
    
    
    
}
