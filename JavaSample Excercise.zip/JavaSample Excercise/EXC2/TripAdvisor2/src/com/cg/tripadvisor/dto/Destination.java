package com.cg.tripadvisor.dto;


import java.util.ArrayList;
import java.util.List;

public class Destination {

	private String city;
	private int rating;
	private String country;
	private List<Review> reviews; 
	public Destination() {
		super();

	}
	public Destination(String city, int rating, String country, List<Review> reviews) {
		super();
		this.city = city;
		this.rating = rating;
		this.country = country;
		this.reviews = reviews;
	}
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	public int getRating() {
		return rating;
	}
	public void setRating(int rating) {
		this.rating = rating;
	}
	public String getCountry() {
		return country;
	}
	public void setCountry(String country) {
		this.country = country;
	}
	public List<Review> getReviewList() {
		return reviews;
	}
	public void setReviewList(List<Review> reviews) {
		this.reviews = reviews;
	}
	@Override
	public String toString() {
		return "\n Destination \n city=" + city + ",\n rating=" + rating + ",\n country=" + country + ",\n reviewList="
				+ reviews + "]";
	}
	
	
}
