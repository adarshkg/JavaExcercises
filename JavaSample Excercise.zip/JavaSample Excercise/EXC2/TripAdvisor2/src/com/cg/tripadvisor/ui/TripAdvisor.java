package com.cg.tripadvisor.ui;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;



import com.cg.tripadvisor.dto.Destination;
import com.cg.tripadvisor.dto.Review;
import com.cg.tripadvisor.dto.Reviewer;
import com.cg.tripadvisor.exceptions.DestinationNotFoundException;
import com.cg.tripadvisor.service.DestinationServiceImplementation;



public class TripAdvisor {

	public static void main(String[] args) {

		DestinationServiceImplementation destinationService  = new DestinationServiceImplementation();
		int choice =0;
		Scanner scan = new Scanner(System.in);
		do {
		System.out.println("\n1. Add Destination\n2. Add Review\n3. Search Review By city\n"
				+ "4.Search Destination By rating\n5. Exit");
		System.out.println("Enter choice");
		choice = scan.nextInt();
		switch (choice) {

		//		Getting destination details from the user and sending to service layer
		
		case 1:
			scan.nextLine();
			System.out.println("********Add Destination*********");
			
			List <Review> reviews = new ArrayList<>();
			System.out.println("Enter city");
			String city =scan.nextLine();
			System.out.println("Enter country");
			String country = scan.next();
			System.out.println("Enter rating");
			int rating = scan.nextInt();		
			Destination destination = new Destination(city, rating, country, reviews);
			destinationService.addDestination(destination);
			
			//		Getting review details from the user and sending to service layer
		
		case 2:
			System.out.println("********Add Review********");
			scan.nextLine();
			System.out.println("Enter review Destination");
			String dest =scan.next();
			scan.nextLine();
			System.out.println("Enter review");
			String rev = scan.nextLine();
		
			System.out.println("Enter your name");
			String name = scan.nextLine();
			
			System.out.println("Enter your email id");
			String email = scan.next();
			Review review = new Review(rev, new Reviewer(name,email));
			ReviewServiceImp reviewService =  new ReviewServiceImp();
			reviewService.addReview(review,dest);
			break;
			
			//		Getting destination from the user and fetching the reviews from the service layer
		
		case 3:	
			System.out.println("********Search Review by Destination********");
			scan.nextLine();
			System.out.println("Enter destination name: ");
			String myDestination=scan.nextLine();
	
				reviews = destinationService.SearchReviewByDestination(myDestination);
				for (Review review : reviews) {
					System.out.println(review.getDescription());
				}

		 
			//		Getting rating from the user and fetching back the specified destination  from service layer
			
		case 4:
			System.out.println("*********Search Destination by rating***************");
			scan.nextLine();
			System.out.println("Enter the destination rating");
			int destinationRating = scan.nextInt();
			List<Destination> destinations;
			
				destinations = destinationService.SearchDestinationByRating(destinationRating);
		
				for (Destination destination2 : destinations) {
					System.out.println(destination2.getCity());
				}
				
		    break;
		case 5:
			break;
		default:
			break;
		}
		}while(choice!=5);

	}


	}
}

