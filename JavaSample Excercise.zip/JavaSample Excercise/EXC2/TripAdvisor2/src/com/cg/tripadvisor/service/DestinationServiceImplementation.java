package com.cg.tripadvisor.service;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import com.cg.tripadvisor.dao.DestinationRepositoryImplemenation;
import com.cg.tripadvisor.dbutil.DbUtil;
import com.cg.tripadvisor.dto.Destination;
import com.cg.tripadvisor.dto.Review;
import com.cg.tripadvisor.exceptions.DestinationNotFoundException;

public class DestinationServiceImplementation implements DestinationService{
	DestinationRepositoryImplemenation destRepo = new DestinationRepositoryImplemenation();


	@Override
	public Destination addDestination(Destination destination) {
		return destRepo.save(destination);	
	}


	@Override
	public List<Review> searchReviewByDestination(String city) throws DestinationNotFoundException {

		Destination destination=destRepo.findDestinationByName(city);
		List<Review> reviewList = new ArrayList<>();
		if(destination!=null) {
			reviewList=destination.getReviewList();

			return reviewList;
		}
		throw new DestinationNotFoundException("Destination not found");
	}



	@Override
	public List<Destination> searchDestinationByRating(int rating) throws DestinationNotFoundException {

		if( destRepo.findDestinationByRating(rating).isEmpty())
			throw new DestinationNotFoundException("Destination not found");
		return destRepo.findDestinationByRating(rating);
	}


	@Override
	public Destination addReviewToDestination(Review review, String city) throws DestinationNotFoundException {

		Destination destination=destRepo.findDestinationByName(city);
		if(destination==null)
			throw new DestinationNotFoundException("Destination Not Found!");
		List<Review> reviews=destination.getReviewList();
		reviews.add(review);
		destination.setReviewList(reviews);
		return destRepo.save(destination);	
	}

}
