package com.cg.tripadvisor.exceptions;

public class DestinationNotFoundException extends Exception {
	
	public DestinationNotFoundException() {
	}
	
	public DestinationNotFoundException(String message) {
		super(message);
	}

}
