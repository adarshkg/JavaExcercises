 /*	@author adgangad
 * project name: TripAdvisor
 * 			This is Destination repsoitory interface 
 * 
*/
package com.cg.tripadvisorjpaspring.repository;

import java.util.List;

import com.cg.tripadvisorjpaspring.dto.Destination;
import com.cg.tripadvisorjpaspring.dto.Review;
import com.cg.tripadvisorjpspring.exceptions.DestinationDetailNotFoundException;


public interface DestinationRepository {
	
	
	public Destination save(Destination destination) throws DestinationDetailNotFoundException;
	public List<Review> findReviewByDestination(String city) throws DestinationDetailNotFoundException;
	public List<Destination> findDestinationByRating(int rating) throws DestinationDetailNotFoundException;

}
