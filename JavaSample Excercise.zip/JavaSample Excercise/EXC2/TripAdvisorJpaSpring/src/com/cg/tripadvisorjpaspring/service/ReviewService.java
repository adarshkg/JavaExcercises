/*
 * @author - adgangad
 */
package com.cg.tripadvisorjpaspring.service;

import com.cg.tripadvisorjpaspring.dto.Review;
import com.cg.tripadvisorjpspring.exceptions.DestinationDetailNotFoundException;



public interface ReviewService {
	
	public Review addReview(Review review,String city) throws DestinationDetailNotFoundException;
	
}
