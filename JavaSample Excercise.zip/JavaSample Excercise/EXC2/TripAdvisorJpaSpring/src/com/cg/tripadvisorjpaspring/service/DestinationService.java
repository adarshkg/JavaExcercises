/*
 * 
 * @author - adgangad
 */
package com.cg.tripadvisorjpaspring.service;

import java.util.List;

import com.cg.tripadvisorjpaspring.dto.Destination;
import com.cg.tripadvisorjpaspring.dto.Review;
import com.cg.tripadvisorjpspring.exceptions.DestinationDetailNotFoundException;



public interface DestinationService {

	public Destination addDestination(Destination destination) throws DestinationDetailNotFoundException;
	public List<Destination> SearchDestinationByRating(int rating) throws DestinationDetailNotFoundException;
	public List<Review> SearchReviewByDestination(String myDestination) throws DestinationDetailNotFoundException;
}
