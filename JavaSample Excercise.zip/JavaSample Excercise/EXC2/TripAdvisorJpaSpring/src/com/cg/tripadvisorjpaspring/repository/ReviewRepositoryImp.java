/*
 * 
 *	@author adgangad
 * project name: TripAdvisor
 * 			This is Review repsoitory interface 
 * 
 * 
 * One Function
 * 		1.save -->[parameter-->Review review, String city, return type-->Review]
 * 
 * 
 * 
 * */

package com.cg.tripadvisorjpaspring.repository;
import java.util.ArrayList;
import java.util.List;
import javax.persistence.EntityManager;
import javax.persistence.TypedQuery;

import com.cg.tripadvisorjpaspring.dto.Destination;
import com.cg.tripadvisorjpaspring.dto.Review;
import com.cg.tripadvisorjpaspring.util.DbUtil;
import com.cg.tripadvisorjpspring.exceptions.DestinationDetailNotFoundException;

public class ReviewRepositoryImp implements ReviewRepository  {
		EntityManager entitymanager;
	
	public Review save(Review review, String city) throws DestinationDetailNotFoundException {
		
//		fetching the destination id from database and storing it in a variable


		Destination destination = new Destination();
		List<Review> reviews = new ArrayList<Review>();
		
		
    	TypedQuery<Destination> query = entitymanager.createQuery(ReviewQuery.querySelectDestination,Destination.class);
		query.setParameter(1, city);
		destination = query.getSingleResult();
		
		reviews = destination.getReview();                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                          
		reviews.add(review);
		destination.setReview(reviews);
		
//		persisting the reviewer details and destination details in database
		entitymanager.persist(review);
		entitymanager.persist(destination);
		entitymanager.getTransaction().commit();
		return review;
		
	}
	
		
	}


