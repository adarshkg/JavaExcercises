 /*	@author adgangad
 * project name: TripAdvisor
 * 			This is review repository interface 
 * 
*/
package com.cg.tripadvisorjpaspring.repository;

import com.cg.tripadvisorjpaspring.dto.Review;
import com.cg.tripadvisorjpspring.exceptions.DestinationDetailNotFoundException;

public interface ReviewRepository {
	
	public Review save(Review review,String city) throws DestinationDetailNotFoundException;

}
