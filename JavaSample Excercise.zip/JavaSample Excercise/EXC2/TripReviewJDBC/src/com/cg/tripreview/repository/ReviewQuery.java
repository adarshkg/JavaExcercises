package com.cg.tripreview.repository;

public interface ReviewQuery {

	public static final String queryInsertReview = "INSERT INTO review(description,destination_id,reviewer_id) VALUES(?,?,?)";
	public static final String queryInsertReviewer ="INSERT INTO reviewer(name,email) VALUES(?,?)";
	public static final String querySelectDestination = "SELECT dest_id FROM destination WHERE dest_city = ?";
	public static final String querySelectReviewer = "SELECT max(reviewer_id) FROM reviewer";
}
