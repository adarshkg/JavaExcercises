/*
 * 
 * 
 * Three functions
 * 		1.save()  [parameters-->Destination destination,return type-->Destination]
 * 		2.findReviewByDestination() -->[parameters-->String city, return type-->List<Review>]
 * 		3.findDestinationByRating() -->[parameters-->int rating, retrun type-->List<Destination>]
 * */




package com.cg.tripreview.repository;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;


import com.cg.tripreview.dto.Destination;
import com.cg.tripreview.dto.Review;
import com.cg.tripreview.exceptions.DestinationDetailNotFoundException;
import com.cg.tripreview.util.DBUtil;

public class DestinationRepositoryImp implements DestinationRepository{
	PreparedStatement pstm;
	
	@Override
	public Destination save(Destination destination) throws DestinationDetailNotFoundException {
		Connection conn = DBUtil.getConnetcion();
		try {
			
			pstm = conn.prepareStatement(DestinationQuery.queryInsertDestination);
			pstm.setString(1, destination.getCity());
			pstm.setInt(2, destination.getRating());
			pstm.setString(3, destination.getCountry());
			
			pstm.executeUpdate();
			
		} catch (SQLException e) {
			
			throw new DestinationDetailNotFoundException("Destination already exist");
		}finally {
		
			try {
				pstm.close();
				conn.close();
			} catch (SQLException e) {
				
				throw new DestinationDetailNotFoundException("connection not able to close");
			}
		}
		return destination;
	}

	@Override
	public List<Review> findReviewByDestination(String city) throws DestinationDetailNotFoundException {
	
		List<Review> myList = new ArrayList<>();
		Connection con = null ;
		try {
			 con = DBUtil.getConnetcion();
			 ResultSet rs;
			
			pstm = con.prepareStatement(DestinationQuery.querySelectDestination);
			pstm.setString(1, city);
			
			rs =pstm.executeQuery();
			
			rs.next();
			int dest_id = rs.getInt("dest_id");
			pstm = con.prepareStatement(DestinationQuery.querySelectReview);
			pstm.setInt(1, dest_id);
			
			rs = pstm.executeQuery();
			while(rs.next()) {
				String description = rs.getString("description");
				Review review = new Review();
				review.setDescription(description);
				myList.add(review);
			}
			
	
		} catch (SQLException e) {

			throw new DestinationDetailNotFoundException("review not found");
			
		} catch (DestinationDetailNotFoundException e) {
			
			throw new DestinationDetailNotFoundException("Destination not found");
			
		}
		finally {
			
			try {
				pstm.close();
				con.close();
			} catch (SQLException e) {

				throw new DestinationDetailNotFoundException("connection not able to close");
			}
		}
			return myList;
		

		
	}

	@Override
	public List<Destination> findDestinationByRating(int rating) throws DestinationDetailNotFoundException {
		List<Destination> myList =  new ArrayList<>();
		Connection conn = null ;
		try {
			 conn = DBUtil.getConnetcion();
			ResultSet rs;
			
			
			pstm = conn.prepareStatement(DestinationQuery.querySelect);	
			pstm.setInt(1, rating);
			rs = pstm.executeQuery();
		    while(rs.next())
		    {
		    	String dest_city = rs.getString("dest_city");
		    	Destination destination = new Destination();
		    	destination.setCity(dest_city);
		    	
		    	myList.add(destination);

		    }
			
		} catch (DestinationDetailNotFoundException e) {
			
			throw new DestinationDetailNotFoundException("Destination detail not found");
		} catch (SQLException e) {

			throw new DestinationDetailNotFoundException("Destination detail not found");
		}finally {
			try {
				
				pstm.close();
				conn.close();
			} catch (SQLException e) {
				
				throw new DestinationDetailNotFoundException("connection not able to close");
			}
			
		}
		return myList;
	}
}