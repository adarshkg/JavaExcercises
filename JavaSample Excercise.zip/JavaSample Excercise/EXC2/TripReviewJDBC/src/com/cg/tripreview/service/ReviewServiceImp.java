/*
 * One function :-
 * 			
 *	1.addReview()  [parameters-->Review review,String city , return type-->Review review]
 *
 *	Here the data is sending to the repository layer
 * 
 * */




package com.cg.tripreview.service;

import java.util.List;

import com.cg.tripreview.dto.Review;
import com.cg.tripreview.exceptions.DestinationDetailNotFoundException;
import com.cg.tripreview.repository.ReviewRepositoryImp;

public class ReviewServiceImp implements ReviewService {
	ReviewRepositoryImp reviewRepo = new ReviewRepositoryImp();
	@Override
	public Review addReview(Review review,String city) throws DestinationDetailNotFoundException {
		Review myReview=reviewRepo.save(review,city);
		if(myReview!=null) 
			return myReview;
		throw new DestinationDetailNotFoundException("Destination not found. Add the destination before writing reveiw!");
	}

}
