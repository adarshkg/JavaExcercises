/*
 * Three function :-
 * 			
 * 			1.add destination()  [parameters-->Destination destination , return type-->Destination destination]
 *		    2.SearchReviewByDestination() [parameters-->string myDestination,return type---->List of Reviews]
 *			3.SearchDestinationByRating() [parameters-->int rating,return type---->List of Destination]
 * 
 * This class is sending the data to the repository layer and then fetching the details from repository layer
 * */




package com.cg.tripreview.service;

import java.util.List;

import com.cg.tripreview.dto.Destination;
import com.cg.tripreview.dto.Review;
import com.cg.tripreview.exceptions.DestinationDetailNotFoundException;
import com.cg.tripreview.repository.DestinationRepository;
import com.cg.tripreview.repository.DestinationRepositoryImp;

public class DestinationServiceImp implements DestinationService{
	DestinationRepositoryImp destRepo;
	public DestinationServiceImp() {
		 destRepo = new DestinationRepositoryImp();
	}
	 
	@Override
	public Destination addDestination(Destination destination) throws DestinationDetailNotFoundException {
		
		return destRepo.save(destination);
	}

	@Override
	public List<Review> SearchReviewByDestination(String myDestination) throws DestinationDetailNotFoundException {
		if(destRepo.findReviewByDestination(myDestination)==null)
			throw new DestinationDetailNotFoundException("Destination not found");
		return destRepo.findReviewByDestination(myDestination);
	}

	@Override
	public List<Destination> SearchDestinationByRating(int rating) throws DestinationDetailNotFoundException {
		if( destRepo.findDestinationByRating(rating).isEmpty())
			throw new DestinationDetailNotFoundException("Destination not found");
		return destRepo.findDestinationByRating(rating);
	}

	

}
