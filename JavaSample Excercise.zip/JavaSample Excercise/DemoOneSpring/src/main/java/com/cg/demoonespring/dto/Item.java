package com.cg.demoonespring.dto;

public class Item {

	
	private int id;
	public Item(int id, String nameOfShop) {
		super();
		this.id = id;
		this.nameOfShop = nameOfShop;
	}


	public int getId() {
		return id;
	}


	public void setId(int id) {
		this.id = id;
	}


	public String getNameOfShop() {
		return nameOfShop;
	}


	public void setNameOfShop(String nameOfShop) {
		this.nameOfShop = nameOfShop;
	}


	private String nameOfShop;
	
	public Item() {
		System.out.println("In item...");
	}
	
	
	public void getData() {
		System.out.println("hi item");
	}
}
