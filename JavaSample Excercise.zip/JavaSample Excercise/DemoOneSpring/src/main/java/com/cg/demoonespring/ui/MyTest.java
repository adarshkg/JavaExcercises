
package com.cg.demoonespring.ui; 
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.cg.demoonespring.dto.Item;
import com.cg.demoonespring.dto.Product;

public class MyTest {

	
	public static void main(String[] args) {

		ApplicationContext app = new ClassPathXmlApplicationContext("spring.xml");	
		Product p = (Product) app.getBean("prod");
		p.getAlldata();
//		p.setId(101);
//		p.setName("asd");
//		p.setPrice(100);
//		p.setDescription("sony.....");
		
//	

//		Product p2 = (Product) app.getBean("prod");
		
		
//		
//		Item it = (Item) app.getBean("it");
//		it.getData();
	}

}
