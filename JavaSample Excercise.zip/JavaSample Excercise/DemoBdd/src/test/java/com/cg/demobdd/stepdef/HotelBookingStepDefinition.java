package com.cg.demobdd.stepdef;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import cucumber.api.PendingException;
import cucumber.api.java.After;
import cucumber.api.java.Before;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class HotelBookingStepDefinition {
	
	WebDriver driver;
	By firstName;
	By lastName;
	By email;
	By button;
	@Before
	private void init() {
	
		System.setProperty("webdriver.chrome.driver", "D:\\Spring\\DemoBdd\\mydriver\\chromedriver.exe");

		driver = new ChromeDriver();
		driver.manage().timeouts().implicitlyWait(10,TimeUnit.SECONDS);
		driver.manage().window().maximize();
//		firstName = By.xpath("//*[@id=\")
	}
	
	
	@After
	private void afterAll() throws InterruptedException {
		Thread.sleep(5000);
		driver.quit();
	}
	
	
	@Given("^Hotel Booking Html page is given$")
	public void hotel_Booking_Html_page_is_given() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		 driver.get("D:/Spring/DemoBdd/mypage/hotelbooking.html");
		 firstName = By.xpath("//*[@id=\"txtFirstName\"]");
		 lastName = By.xpath("//*[@id=\"txtLastName\"]");
		 email = By.id("txtEmail");
		 button = By.xpath("//*[@id=\"btnPayment\"]");
	   
	}

	@When("^Clicking on submit button for first name validation$")
	public void clicking_on_submit_button_for_first_name_validation() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		driver.findElement(button).click();
	}

	@Then("^alert is coming 'Please Fill the first Name'$")
	public void alert_is_coming_Please_Fill_the_first_Name() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		String actualData = driver.switchTo().alert().getText();
	}

	@When("^Clicking on submit button for last name validation$")
	public void clicking_on_submit_button_for_last_name_validation() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}

	@Then("^alert is coming 'Please Fill the last Name'$")
	public void alert_is_coming_Please_Fill_the_last_Name() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}

	@When("^Clicking on submit button for email validation$")
	public void clicking_on_submit_button_for_email_validation() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}

	@Then("^alert is coming 'Please Fill the email'$")
	public void alert_is_coming_Please_Fill_the_email() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}

	@When("^Clicking on submit button for mobile validation$")
	public void clicking_on_submit_button_for_mobile_validation() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}

	@Then("^alert is coming 'Please Fill the Mobile no'$")
	public void alert_is_coming_Please_Fill_the_Mobile_no() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}

	@When("^Clicking on submit button for city validation$")
	public void clicking_on_submit_button_for_city_validation() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}

	@Then("^alert is coming 'Please Fill the City'$")
	public void alert_is_coming_Please_Fill_the_City() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}

	@When("^Clicking on submit button for state validation$")
	public void clicking_on_submit_button_for_state_validation() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}

	@Then("^alert is coming 'Please Fill the State'$")
	public void alert_is_coming_Please_Fill_the_State() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}
}
