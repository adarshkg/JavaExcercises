package com.cg.product.service;

import java.util.List;

import com.cg.product.exception.ProductException;
import com.cg.product.pojo.Product;

public interface IProductService {

	public void addProduct(Product pro);
	public List<Product>showByLimit(int min,int max) throws ProductException;
	public Product showById(int id) throws ProductException;
	
	void deletById(Product pro);
	
}
