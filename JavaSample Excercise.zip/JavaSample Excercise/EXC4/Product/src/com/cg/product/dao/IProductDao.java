package com.cg.product.dao;

import java.util.List;

import com.cg.product.exception.ProductException;
import com.cg.product.pojo.Product;

public interface IProductDao {
	public Product save(Product pro) throws ProductException;

	public List<Product> findByLimit(int min, int max) throws ProductException;
	public Product findById(int id) throws ProductException;
	public void removeById(Product pro) throws ProductException;
}
