package com.cg.product.service;

import java.util.List;

import com.cg.product.dao.ProductDao;
import com.cg.product.exception.ProductException;
import com.cg.product.pojo.Product;

public class ProductService implements IProductService{
	ProductDao dao = new ProductDao();
	@Override
	public void addProduct(Product pro) {
		dao.save(pro);
		
	}
	public List<Product> showAll() {
		return dao.showAll();
		
	}
	
	public List<Product>showByLimit(int min,int max) throws ProductException{
		
		
		return dao.findByLimit(min, max);
	
	}
	@Override
	public Product showById(int id) throws ProductException {
		// TODO Auto-generated method stub
		return dao.findById( id);
	}
	@Override
	public void deletById(Product pro) {
		
		 dao.removeById(pro);
	}
	

}
