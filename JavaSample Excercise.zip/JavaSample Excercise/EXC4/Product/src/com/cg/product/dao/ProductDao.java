package com.cg.product.dao;

import java.util.ArrayList;
import java.util.List;

import com.cg.product.exception.ProductException;
import com.cg.product.pojo.Product;

public class ProductDao implements IProductDao {

	List<Product> proList = new ArrayList<>(); 
	@Override
	public Product save(Product pro) {
		// TODO Auto-generated method stub
		proList.add(pro);
		return pro;
	}
	public List<Product> showAll() {
		return proList;
	}
	@Override
	public List<Product> findByLimit(int min, int max) throws ProductException{
		
		for (Product product : proList) {
			List<Product>proSearch = new ArrayList<>();
			if(product.getPrice()>=min&&product.getPrice()<=max) {
				 proSearch.add(product);
			}
			if(!proSearch.isEmpty())
				return proSearch;
			else
				 throw new ProductException("No products ");
		
	}
		return proList;
	

}
	public Product findById(int id) throws ProductException {
		
		for (Product product : proList) {
			if(product.getId()==id) {
				return product;
			}
		}
		throw new ProductException("Id not found");
	}
	
	@Override
	public void removeById(Product pro) {
		proList.remove(pro);
		
	}
}

