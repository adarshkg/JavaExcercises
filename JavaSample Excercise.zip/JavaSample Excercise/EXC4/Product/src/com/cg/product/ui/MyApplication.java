package com.cg.product.ui;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import com.cg.product.exception.ProductException;
import com.cg.product.pojo.Product;
import com.cg.product.service.ProductService;

public class MyApplication {

	public static void main(String[] args) {
		Scanner scan = new Scanner(System.in);
		ProductService service = new ProductService();
		int choice = 0;
		do {
			printdetails();
			System.out.println("Enter your choice");
			choice = scan.nextInt();
			switch (choice) {
			case 1:
				System.out.println("Enter product id");
				int id =scan.nextInt();
				System.out.println("Enter product name");
				String name = scan.next();
				System.out.println("Enter product price");
				Double price =scan.nextDouble();
				
				Product pro = new Product();
				
				pro.setId(id);
				pro.setName(name);
				pro.setPrice(price);
				
				service.addProduct(pro);
				
				
				
				break;
			case 2:
				List<Product> proList = service.showAll();
				for (Product product : proList) {
					System.out.println("Product id is "+product.getId());
					System.out.println("Product name is "+product.getName());
					System.out.println("Product cost is "+product.getPrice());

				}
				
				break;
			case 3:
				System.out.println("Search the lowest price");
				int min = scan.nextInt();
				System.out.println("Search the highest price");
				int max = scan.nextInt();
				
				List<Product> proFilter = null;
				try {
					proFilter = service.showByLimit(min,max);
				} catch (ProductException e) {
					// TODO Auto-generated catch block
					System.out.println("There is no product in this limit");
				}
				for (Product product : proFilter) {
					System.out.println("Product id is "+product.getId());
					System.out.println("Product name is "+product.getName());
					System.out.println("Product cost is "+product.getPrice());
				}

				break;
			case 4:
				System.out.println("Search by Id");
				int sid =scan.nextInt();
				
				try {
					Product proS = service.showById(sid);
					
					if(proS!=null) {
					
						System.out.println("Product id is "+proS.getId());
						System.out.println("Product name is "+proS.getName());
						System.out.println("Product cost is "+proS.getPrice());
					}
				} catch (ProductException e) {
					// TODO Auto-generated catch block
					System.out.println("Id not found");
				}
				
				
				break;
			case 5:
				System.out.println("enter Id");
				int uid =scan.nextInt();
				
				
				break;
			case 6:
				System.out.println("Enter Id");
				int did =scan.nextInt();
				try {
					Product proS = service.showById(did);
					if(proS!=null) {
						service.deletById(proS);
					}
				} catch (ProductException e1) {
					// TODO Auto-generated catch block
					System.out.println("no item found to delete");
				}
		
				
				break;


			default:
				break;
			}
		}while(choice!=6);
		

	}
   public static void printdetails() {
	   System.out.println("1.Add Product");
	   System.out.println("2.Show Product");
	   System.out.println("3.Search by Price limit");
	   System.out.println("4.Search by Id ");
	   System.out.println("5.Update");
	   System.out.println("6.Delete");
   }
}
