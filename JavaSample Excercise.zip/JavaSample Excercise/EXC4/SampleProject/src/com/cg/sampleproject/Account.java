package com.cg.sampleproject;

public class Account {

}
