package com.cg.sampleproject;

public class Transaction {

}
