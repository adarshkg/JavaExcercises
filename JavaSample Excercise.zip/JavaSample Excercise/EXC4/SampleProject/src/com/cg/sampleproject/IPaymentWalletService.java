package com.cg.sampleproject;

public interface IPaymentWalletService {
		
	
	 public User createRegistration(User user);
	 public User login(User user);
}
