package com.cg.sampleproject;

public class User {

}
