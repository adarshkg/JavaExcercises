package com.cg.customerdemo.ui;

import com.cg.customerdemo.service.CustomerService;
import com.cg.customerdemo.service.CustomerServiceImp;

public class MyApp {
	
	public static void main(String[] args) {
		CustomerService service = new CustomerServiceImp();
		
		System.out.println(service.find().get(0).getFirstNmae());
	}
	

	
}
