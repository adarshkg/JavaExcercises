package com.cg.samplemap.ui;

import java.util.HashMap;
import java.util.Map;

public class MyApplication {

	public static void main(String[] args) {
		Map<Integer, String> myMap =  new HashMap<Integer, String>();
	    
		myMap.put(1010, "A");
		myMap.put(9111, "E");
		myMap.put(1290, "B");
		myMap.put(1011, "S");
		
		System.out.println(myMap);
	}

}
