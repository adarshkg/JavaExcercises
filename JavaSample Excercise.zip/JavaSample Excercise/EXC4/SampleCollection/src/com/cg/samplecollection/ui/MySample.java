package com.cg.samplecollection.ui;

import java.util.HashSet;
import java.util.Set;

public class MySample {

	public static void main(String[] args) {
		Person personOne =  new Person("Vishnu"); 
		Person personTwo =  new Person("Sachin"); 
		Person personThree =  new Person("Sai"); 
		Person personFour =  new Person("Harish"); 
		Person personFive =  new Person("Sulekha"); 
		Person personSix =  new Person("Jaya"); 
		Person personSeven =  new Person("Barna"); 
		Person personEight =  new Person("Hema"); 
		Person personNine =  new Person("Shailendra"); 
		Person personTen =  new Person("Manthan"); 
		
		Set<Person> mySet =  new HashSet<Person>();
		
		mySet.add(personOne);
		mySet.add(personTwo);
		mySet.add(personThree);
		mySet.add(personFour);
		mySet.add(personFive);
		mySet.add(personSix);
		mySet.add(personSeven);
		mySet.add(personEight);
		mySet.add(personNine);
		mySet.add(personTen);
		System.out.println(Person.count);


	}

}
