package com.cg.samplecollection.ui;

public class Person {

	        static int count = 0;
			private String name;

			public Person(String name) {
				super();
				this.name = name;
			}

			public String getName() {
				return name;
			}

			public void setName(String name) {
				this.name = name;
			}

			@Override
			public int hashCode() {
				return 10;
//				return name.charAt(0);
				//return name.hashCode();
				
			}

			@Override
			public boolean equals(Object obj) {
				System.out.println("In equals ");
				count++;
				return(this.getName().equals(((Person) obj).getName()));
			}
			
			

	}
			

