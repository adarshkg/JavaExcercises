package com.cg.sample.ui;

import java.math.BigDecimal;
import java.math.BigInteger;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;
import java.util.TreeMap;

import javax.swing.text.html.HTMLDocument.Iterator;

public class MyApplication {

	public static void main(String[] args) {
		Employee<Integer,Double> empOne = new Employee<Integer,Double>(1006,"R",9999.0);
		Employee <BigInteger,BigDecimal>empTwo = new Employee<BigInteger,BigDecimal> (new BigInteger("1025"),"Z",new BigDecimal(9995.0));
		Employee<Integer,Double> empThree = new Employee <Integer,Double>(1001,"V",9999.0);
		Employee<Integer,Double> empFour = new Employee<Integer,Double>(1006,"a",9999.0);

//
//		List<Employee> myList = new ArrayList<Employee>();
		
		
		Map< Integer,Employee> myMap = new HashMap<Integer,Employee>();
		
		myMap.put(1,empOne);
		myMap.put(2,empTwo);
		myMap.put(3,empThree);
		myMap.put(4,empFour);
		
		
		
		Collection<Employee> myCollection = myMap.values();
		List<Employee> empList = new ArrayList<Employee>(myCollection);
		Collections.sort(empList,new EmployeeSorting());
		
		for (Employee employee : empList) {
			System.out.println("Name is "+employee.getName());
		}
		

		
		
		
		
		
//	
//		Map< Employee,Integer> treeMap = new TreeMap<Employee,Integer>(myMap);
//		
//		
//		for (Employee emp : treeMap.keySet()) {
//			System.out.println(emp);
//		}
//		
//		Set<?> mySet = myMap.entrySet();
//		Iterator it = mySet.iterator();
//		while(it.hasNext()) {
//			System.out.println(it.next());
//		}

		
	}

}
