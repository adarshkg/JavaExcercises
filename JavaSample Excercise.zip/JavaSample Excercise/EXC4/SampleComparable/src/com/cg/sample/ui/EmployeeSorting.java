package com.cg.sample.ui;

import java.util.Comparator;

public class EmployeeSorting  implements Comparator<Employee>{

	@Override
	public int compare(Employee o1, Employee o2) {
		// TODO Auto-generated method stub
		return o1.getName().compareToIgnoreCase(o2.getName());
	}

//	@Override
//	public int compare(Employee o1, Employee o2) {
//		if(o1.getId()<o2.getId()) {
//			return 1;
//		}
//		else if(o1.getId()>o2.getId()) {
//			return -1;
//		}else return 0;
	}
