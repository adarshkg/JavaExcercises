package om.cg.demos;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.Enumeration;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.cg.demos.GzipUtilities;

/**
 * Servlet implementation class ShowRequestHeaders
 */
@WebServlet("/ShowRequestHeaders")
public class ShowRequestHeaders extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public ShowRequestHeaders() {
        super();
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.getWriter().append("Served at: ").append(request.getContextPath());
		
		
		
		
		
		PrintWriter out;
		if(GzipUtilities.isGzipSupported(request)&&	!GzipUtilities.isGzipDisabled(request)) {
			out = GzipUtilities.getZipWriter(response);
			response.setHeader("Content ENCODING", "GZip");
		}
		else
		{
		out = response.getWriter();
		}
		
		response.setContentType("text/html");
		out.println("<!DOCTYPE HTML");
		out.println("<html>");
		out.println("<head>");
		out.println("<title>");
		out.println("</title>");
		out.println("</head>");
		out.println("<body>");
		out.println("<h1> All request header </h1>");
		
		out.println("<p><b>Request Method : </b> "+request.getMethod());
		out.println("<p><b>Request URI : </b> "+request.getRequestURI());
		out.println("<p><b>Request Protocol : </b> "+request.getProtocol());
		
		Enumeration<String> headerNames = request.getHeaderNames();
		while(headerNames.hasMoreElements()) {
			String headerName = headerNames.nextElement();
			out.println("<p><b> "+headerName+"</b>"+request.getHeader(headerName)+"</p>");
		}
		String dummyLine="asfasd ajsdgas ashdjkash daskdjha s";
		for(int i=0;i<10000;i++) {
			out.println(dummyLine);
		}
		out.println("</body>");
		out.println("</html>");
		out.close();
		
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doGet(request, response);
	}

}
