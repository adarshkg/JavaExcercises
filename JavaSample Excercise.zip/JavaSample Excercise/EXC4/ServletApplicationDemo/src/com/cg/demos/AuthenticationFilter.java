package com.cg.demos;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.Date;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.annotation.WebFilter;

/**
 * Servlet Filter implementation class AuthenticationFilter
 */
@WebFilter("/AuthenticationFilter")
public class AuthenticationFilter implements Filter {

    /**
     * Default constructor. 
     */
    public AuthenticationFilter() {
    }

	/**
	 * @see Filter#destroy()
	 */
	public void destroy() {
		System.out.println("In destroy method"+this.getClass().getName());
	}

	/**
	 * @see Filter#doFilter(ServletRequest, ServletResponse, FilterChain)
	 */
	public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain) throws IOException, ServletException {
		// place your code here
		System.out.println("in doFilter method"+this.getClass().getName());
		
		String uname= request.getParameter("username");
		String password = request.getParameter("password");
		
		String ipAdress = request.getRemoteAddr();
		if(uname.equals("asd")&&password.equals("asd")){
			
		System.out.println("User logged in "+ ipAdress +" at "+new Date().toString());
		chain.doFilter(request, response);
		}
		else {
			PrintWriter out = response.getWriter();
			out.println("<h3>You're not authorised to acess the resource</h3>");
			
		}
		
		// pass the request along the filter chain
		
	}

	/**
	 * @see Filter#init(FilterConfig)
	 */
	public void init(FilterConfig fConfig) throws ServletException {
	System.out.println("in init method"+this.getClass().getName());
	
	
	}
	

}
