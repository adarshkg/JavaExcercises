package com.cg.customerdemo.repo;
import java.util.List;

import com.cg.customerdemo.dto.Customer;

public interface CustomerRepo {

	public List <Customer> find();
}
