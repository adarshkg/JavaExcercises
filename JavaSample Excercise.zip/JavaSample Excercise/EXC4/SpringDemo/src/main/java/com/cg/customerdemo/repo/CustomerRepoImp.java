package com.cg.customerdemo.repo;

import java.util.ArrayList;
import java.util.List;

import com.cg.customerdemo.dto.Customer;

public class CustomerRepoImp implements CustomerRepo {

	public List<Customer> find() {
		
		Customer customer = new Customer();
		List<Customer> myList = new ArrayList<Customer>();
		
		customer.setFirstNmae("Adarsh");
		customer.setLastName("G");
		
		myList.add(customer);
		return myList;
	}

}
