package com.cg.customerdemo.dto;

public class Customer {

	private String firstNmae;
	private String lastName;

	public Customer() {
		super();
	}

	public Customer(String firstNmae, String lastName) {
		super();
		this.firstNmae = firstNmae;
		this.lastName = lastName;
	}

	@Override
	public String toString() {
		return "Customer [firstNmae=" + firstNmae + ", lastName=" + lastName + "]";
	}

	public String getFirstNmae() {
		return firstNmae;
	}

	public void setFirstNmae(String firstNmae) {
		this.firstNmae = firstNmae;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

}
