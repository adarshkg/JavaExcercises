package com.cg.customerdemo.service;

import java.util.List;

import com.cg.customerdemo.dto.Customer;
import com.cg.customerdemo.repo.CustomerRepo;
import com.cg.customerdemo.repo.CustomerRepoImp;

public class CustomerServiceImp implements CustomerService {

	CustomerRepo repo = new CustomerRepoImp();
	
	public List<Customer> find() {
		return repo.find();
	}

}
