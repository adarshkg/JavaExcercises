package com.cg.customerdemo.service;

import java.util.List;

import com.cg.customerdemo.dto.Customer;

public interface CustomerService {

	public List<Customer> find();
}
