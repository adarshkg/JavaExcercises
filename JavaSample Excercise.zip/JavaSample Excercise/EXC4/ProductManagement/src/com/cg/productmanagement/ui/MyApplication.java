package com.cg.productmanagement.ui;

import java.util.Scanner;

import com.cg.productmanagement.dto.Product;
import com.cg.productmanagement.service.IProductService;
import com.cg.productmanagement.service.ProductService;

public class MyApplication {

	public static void main(String[] args) {
		int choice =0;
		printDetails();
		IProductService service =new ProductService();
		Scanner scan = new Scanner(System.in);

		
		do {
			
			System.out.println("Enter the choice");
			choice = scan.nextInt();
			switch (choice) {
			case 1:
				Product product =new Product();
				
				System.out.println("Enter prodId");
				int prodId = scan. nextInt();

				System.out.println("Enter prodName");
				String productName = scan. next();

				System.out.println("Enter product price");
				double productPrice = scan. nextDouble();
				
				System.out.println("Enter product description");
				String prodDescription = scan. next();
				
				
				product.setId(prodId);
				product.setName(productName);
				product.setPrice(productPrice);
     			product.setDescription(prodDescription);
     			
     			service.addProduct(product);
     			
     			
				break;
			case 2:
				Product[] allData = service.showAllProduct();
				for (Product product2: allData) {
					System.out.println("Product id is "+product2.getId());
					System.out.println("Product id is "+product2.getName());
					System.out.println("Product id is "+product2.getPrice());
					System.out.println("Product id is "+product2.getDescription());
					
				}
				break;
			case 3:
				System.out.println("Enter the maximum price range");
				int max =scan.nextInt();
				System.out.println("Enter the minimum price range");
				int min =scan.nextInt();
				
				break;
			default:
				break;
			}
			
		}while(choice!=3);

	}
private static void printDetails() {
	System.out.println("\n\n1.Add Product\n2.Show All Product\n3.Search By priceLimit\n4.SearchById \n5.Update\n6.delete\n7Exit");

}
}
