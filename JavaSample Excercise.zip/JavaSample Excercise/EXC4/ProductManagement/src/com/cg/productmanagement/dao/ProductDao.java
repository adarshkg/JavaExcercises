package com.cg.productmanagement.dao;

import com.cg.productmanagement.dto.Product;

public class ProductDao implements IProductDao{
	int i=0;

	Product prod[];	
	
	public ProductDao() {
		prod = new Product[5];
		// TODO Auto-generated constructor stub
	}

	@Override
	public Product addProduct(Product pro) {
		// TODO Auto-generated method stub
			
			prod[i] = new Product();
			prod[i].setId(pro.getId());
			prod[i].setName(pro.getName());
			prod[i].setPrice(pro.getPrice());
 			prod[i].setDescription(pro.getDescription());
 			i++;
		return pro;
	}

	
	@Override
	public Product[] showAll() {
		
		return prod;
	}

	@Override
	public Product[] findByLimit(int min, int max) {
		
		
		
		
		return null;
	}

}
