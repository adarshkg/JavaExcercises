package com.cg.productmanagement.junittest;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import com.cg.productmanagement.dto.Product;
import com.cg.productmanagement.service.IProductService;
import com.cg.productmanagement.service.ProductService;

class ProductTest {
	
	IProductService service;
	Product product;
	
	@BeforeEach
	public void beforeTest(){
		service = new ProductService();
		product = new Product();
		product.setId(1001);
		product.setName("Mobile");
		product.setPrice(30000.10);
		product.setDescription("Its good mobile ny LG");
	}
	
	@Test
	public void myTest() {
		assertNotNull(service.addProduct(product));
	}
	
	@Test
	public void myTestTwo() {
		assertNotNull(service.showAllProduct());
	}
	
	
	@AfterEach
	public void afterEach() {
		service = null;
	}
}
