package com.cg.productmanagement.ui;

import java.util.Scanner;

import com.cg.productmanagement.dto.Product;

public class MyProduct {

	public static void main(String[] args) {
		
		int choice;
		int prodId;
		String productName;
		double productPrice;
		String prodDescription;
		
		
		Product [] product = new Product[5];
		
		
		int i=0;
		do {
			
			System.out.println("\n\n1.Add Product\n2.Show All Product\n3.Exit");
			Scanner scan = new Scanner(System.in);
			System.out.println("enter your choice(1/2/3)");
			choice = scan. nextInt();
			
			
			switch(choice) {
			
			case 1:
				System.out.println("Enter prodId");
				prodId = scan. nextInt();

				System.out.println("Enter prodName");
				productName = scan. next();

				System.out.println("Enter product price");
				productPrice = scan. nextDouble();
				
				System.out.println("Enter product description");
				prodDescription = scan. next();
				

				
				product[i] = new Product();
				product[i].setId(prodId);
				product[i].setName(productName);
				product[i].setPrice(productPrice);
     			product[i].setDescription(prodDescription);
				i++;
				
				break;
				
			case 2:
				
				for(i=0;product[i]!=null;i++)
				{
				System.out.println("\n\nProduct id is "+product[i].getId());
				System.out.println("Product Name is " + product[i].getName());
				System.out.println("product price is "+ product[i].getPrice());
				System.out.println("Product description is"+product[i].getDescription());
				}
				break;
				
				
			case 3:
				
				break;
			
			}
		}while(choice!=3);
		

	}

}
