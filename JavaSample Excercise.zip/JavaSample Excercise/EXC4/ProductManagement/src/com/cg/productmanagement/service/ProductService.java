package com.cg.productmanagement.service;

import com.cg.productmanagement.dao.IProductDao;
import com.cg.productmanagement.dao.ProductDao;
import com.cg.productmanagement.dto.Product;

public class ProductService implements IProductService {
    IProductDao dao;
    
	public ProductService() {
		dao =new ProductDao();
	}

	@Override
	public Product addProduct(Product product) {
		// TODO Auto-generated method stub
		return dao.addProduct(product);
	}

	@Override
	public Product[] showAllProduct() {
		// TODO Auto-generated method stub
		return dao.showAll();
	}

	@Override
	public Product[] searchByLimit(int min,int max) {
		// TODO Auto-generated method stub
		return dao.findByLimit(min,max);
	}

}
