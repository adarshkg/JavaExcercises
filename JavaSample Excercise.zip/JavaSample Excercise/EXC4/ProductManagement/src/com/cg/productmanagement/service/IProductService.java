package com.cg.productmanagement.service;

import com.cg.productmanagement.dto.Product;

public interface IProductService {
	
	public Product addProduct(Product product);
	public Product[] showAllProduct();
	public Product[] searchByLimit(int min,int max);
}
