package com.cg.thread.ui;

public class MyRunnable implements Runnable{

	@Override
	public void run() {
		for(int i =0;i<2;i++) {
			System.out.println("Thread is running "+Thread.currentThread().getName()+i);
//			System.out.println(Thread.currentThread().getPriority());
//			System.out.println(Thread.currentThread().isAlive());
			try {
				Thread.currentThread().sleep(1000);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		
	}

}
