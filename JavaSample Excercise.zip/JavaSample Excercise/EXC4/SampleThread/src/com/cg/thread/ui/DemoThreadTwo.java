package com.cg.thread.ui;

public class DemoThreadTwo {
	public static void main(String[] args) {
		
			Sleepdemo sl =new Sleepdemo();
			Thread t = new Thread(sl);
			Thread t1 = new Thread(sl);
			t.setPriority(1);
			t1.setPriority(8);
			t.start();
			t1.start();
	}

}
