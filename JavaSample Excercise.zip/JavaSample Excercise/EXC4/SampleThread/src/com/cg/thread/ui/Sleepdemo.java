package com.cg.thread.ui;

public class Sleepdemo implements Runnable {

	@Override
	public void run() {
		
		for(int i=1;i<101;i++) {
			if(i%10==0) {
				System.out.println(Thread.currentThread().getName()+"Every 10");
			}
			System.out.println("\n"+i);
		
		}
	
		
	}

}
