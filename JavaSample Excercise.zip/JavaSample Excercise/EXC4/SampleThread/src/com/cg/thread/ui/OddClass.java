package com.cg.thread.ui;

public class OddClass implements Runnable {
	int odd;
	public OddClass(int odd) {
		super();
//		System.out.println("in odd constructo");
		this.odd = odd;
	}
	@Override
	public void run() {
	
		if(odd%2!=0) {
			System.out.println("number is odd");
		}
	}

}
