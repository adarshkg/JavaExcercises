package com.cg.thread.ui;

public class EvenClass implements Runnable {
	int even;
	public EvenClass(int even) {
		super();
		this.even = even;
	}
	@Override
	public void run() {

		if(even%2==0) {
			System.out.println("the number is even");
		}
		
	}

}
