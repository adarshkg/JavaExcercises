package com.cg.thread.ui;

public class DemoThread {
		public static void main(String []args) {
//			MyRunnable myrunnable = new MyRunnable();
//			Thread t1 = new Thread(myrunnable);
//			t1.setName("adarsh");
//			t1.start();
//			
			OddClass od = new OddClass(9);
			Thread odd = new Thread(od);
			odd.start();
			
			
			
			EvenClass ev = new EvenClass(10);
			Thread even =new Thread(ev);
			even.start();
//			System.out.println(Thread.currentThread().getName());
			
			
			
//			Thread t2 = new Thread(myrunnable);
//			t2.setName("sachin");
//			t2.start();
//			System.out.println(Thread.currentThread().getName());
//			try {
//				Thread.sleep(5000);
//			} catch (InterruptedException e) {
//				// TODO Auto-generated catch block
//				e.printStackTrace();
//			}
//			System.out.println(Thread.currentThread().isAlive());
//	
		}
		
}
