package com.cg.ProductSpringBoot.dto;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;

@Entity
@Table(name="data_products")
public class Product {

	@Id
	@Column(name="prod_id")
	private int prodId;
	@Column(name="prod_name")
	private String prodNAme;
	@Column(name="prod_price")
	private double price;
	@Column(name="prod_desc")
	private String description;
	
	@OneToOne(cascade=CascadeType.ALL)
	@JoinColumn(name="prod_inventory")
	private Inventory inventory;
	
	public Product() {
	
	}

	public Product(int prodId, String prodNAme, double price, String description, Inventory inventory) {
		super();
		this.prodId = prodId;
		this.prodNAme = prodNAme;
		this.price = price;
		this.description = description;
		this.inventory = inventory;
	}

	public int getProdId() {
		return prodId;
	}

	public void setProdId(int prodId) {
		this.prodId = prodId;
	}

	public String getProdNAme() {
		return prodNAme;
	}

	public void setProdNAme(String prodNAme) {
		this.prodNAme = prodNAme;
	}

	public double getPrice() {
		return price;
	}

	public void setPrice(double price) {
		this.price = price;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public Inventory getInventory() {
		return inventory;
	}

	public void setInventory(Inventory inventory) {
		this.inventory = inventory;
	}

	@Override
	public String toString() {
		return "Product [prodId=" + prodId + ", prodNAme=" + prodNAme + ", price=" + price + ", description="
				+ description + ", inventory=" + inventory + "]";
	}

	
	
}
