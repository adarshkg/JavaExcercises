package com.cg.ProductSpringBoot.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.config.annotation.CorsRegistry;

import com.cg.ProductSpringBoot.dto.Inventory;
import com.cg.ProductSpringBoot.dto.Product;
import com.cg.ProductSpringBoot.services.ProductService;

@RestController
@RequestMapping("/product")
@CrossOrigin(origins="http://localhost:4200")
public class ProductController {
	
	@Autowired
	ProductService productservice;
	
	
	  public void addCorsMappings(CorsRegistry registry) {
          registry.addMapping("/**")
                  .allowedMethods("*")
                  .allowedOrigins("http://localhost:4200");
      }

	
	
	
/*	
	@RequestMapping(method=RequestMethod.GET,value="/checkname/{uname}")
//	@GetMapping("checkname")
	public String getName(@PathVariable("uname") String mname,
			@RequestParam("prodid") String id) {
		System.out.println(mname);
		return "Capgemini "+mname+" "+id;
		
	}

	
	@RequestMapping(method=RequestMethod.POST,value="/checkname")
	public String getData(@RequestParam("prodid") int pid,
			@RequestParam("prodname") String pname,
			@RequestParam("prodprice") String pprice
			)
{
		return "Welcome "+pid+" "+pname+" "+pprice;
		
	}*/
	
	@RequestMapping(value="/add",method=RequestMethod.POST)
	public  ResponseEntity<Product> addProduct(@RequestBody Product pro) {
		Product product = productservice.addProduct(pro);
		if(product==null) {
			return new ResponseEntity("Product not added",HttpStatus.NOT_FOUND);
			
		}
		return new ResponseEntity<Product>(product,HttpStatus.OK);
		
	}
	
	@RequestMapping(value="/show",method=RequestMethod.GET)
	public ResponseEntity <List<Product>> showAllProduct(){
		List<Product> myList = productservice.showAll();
		if(myList.isEmpty()) {
			return new ResponseEntity("No product to Show",HttpStatus.NOT_FOUND);
		}
		return new ResponseEntity<List<Product>>(myList,HttpStatus.OK);
		
	}
	
	
	
	@RequestMapping(value="/search",method=RequestMethod.GET)
	public ResponseEntity<List<Product>> showProduct(@RequestParam("name") String name) {
		List<Product> myList = productservice.findByName(name);	
		if(myList.isEmpty()) {
			return new ResponseEntity("No product to Show",HttpStatus.NOT_FOUND);
		}
		return new ResponseEntity<List<Product>>(myList,HttpStatus.OK);
		
	}
	
	@RequestMapping(value="/searchprice",method=RequestMethod.POST)
	public ResponseEntity<List<Product>> showProductByPrice(@RequestParam("low") double lowprice,@RequestParam("high") double highprice) {

		List<Product> myList = productservice.findByPrice(lowprice,highprice);	
		if(myList.isEmpty()) {
			return new ResponseEntity("No product to Show",HttpStatus.NOT_FOUND);
		}
		return new ResponseEntity<List<Product>>(myList,HttpStatus.OK);
		
	}
	
	
	

          
	
/*	@RequestMapping(value="/addall",method=RequestMethod.POST)
	public ResponseEntity<Product> addAll(@RequestParam("id") int pid,
			@RequestParam("name") String pname,
			@RequestParam("price") Double price,
			@RequestParam("desc") String desc,
			@RequestParam("inid") int inid,
			@RequestParam("inname") String inname) {
		
		Inventory inventory = new Inventory();
		inventory.setId(inid);
		inventory.setName(inname);
		
		
		Product product = new Product();
		product.setProdId(pid);
		product.setProdNAme(pname);
		product.setPrice(price);
		product.setDescription(desc);
		product.setInventory(inventory);
		
		Product pro = productservice.addProduct(product);
	
		if(pro==null) {
			return new ResponseEntity("No product added",HttpStatus.NOT_FOUND);
		}
		return new ResponseEntity<Product>(pro,HttpStatus.OK);
		
	}*/
@RequestMapping(value="/addall",method=RequestMethod.POST)

	public ResponseEntity<Product> addAll(@ModelAttribute Product product) {
		
		Product pro = productservice.addProduct(product);
	
		if(pro==null) {
			return new ResponseEntity("No product added",HttpStatus.NOT_FOUND);
		}
		return new ResponseEntity<Product>(pro,HttpStatus.OK);
		
	}
	
/*	@RequestMapping(value="/search",method=RequestMethod.GET)
	public Product showProduct(@RequestParam("prodId") String id) {
		int pid = Integer.parseInt(id);
		return productservice.searchById(pid);
		
	}
	@RequestMapping(value="/update",method=RequestMethod.PUT)
	public Product update(@RequestBody Product product){
		
		Product prod  = productservice.searchById(product.getProdId()); 
		prod.setPrice(product.getPrice());
		prod.setProdNAme(product.getProdNAme());
		prod.setDescription(product.getDescription());
		return prod;
		
	}
	
	@RequestMapping(value="/delete",method=RequestMethod.DELETE)
	public Product delete(@RequestParam("prodId") String id){
		
		int pid = Integer.parseInt(id);
		Product prod  = productservice.searchById(pid);
		
		return productservice.delete(prod); 
	
	}*/
	
	
}
