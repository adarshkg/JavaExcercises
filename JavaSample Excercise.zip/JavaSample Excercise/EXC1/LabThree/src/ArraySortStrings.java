import java.lang.reflect.Array;
import java.util.Arrays;
import java.util.Scanner;

public class ArraySortStrings {



		public static void main(String[] args) {
		
			String [] str = {"hi","how","are","you"}; 
			Arrays.sort(str);
			System.out.println();

		  int length =str.length;
		  if(length%2==0) {
			  for(int i=0;i<length/2;i++) {
				  str[i] = str[i].toUpperCase();
			  }
			  for(int i =length/2;i<length;i++) {
				  str[i] = str[i].toLowerCase();
			  }
		  }
		  else {
			  for(int i=0;i<length+1/2;i++) {
				  str[i] = str[i].toUpperCase();
			  }
			  for(int i =length/2+1;i<length;i++) {
				  str[i] = str[i].toLowerCase();
			  }
		  }
			for(int i=0;i<str.length;i++) {
				System.out.println(str[i]);
			}
		}
		


	}
