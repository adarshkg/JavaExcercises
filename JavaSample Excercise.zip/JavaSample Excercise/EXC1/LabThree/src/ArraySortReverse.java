import java.util.Arrays;
import java.util.Scanner;

public class ArraySortReverse {
	public static void main(String[] args) 
	{
         int[] array = new int [5];
        Scanner scan = new Scanner(System.in);
 		System.out.println("Enter elements");
 		for(int i =0;i<5;i++)
 		{ 
 			array[i] = scan.nextInt();
 		}
            getSorted(array);
	} 
	public static void getSorted(int [] array) {
		String str,rev;
		int [] reversedArray = new int[5];
		for(int i =0;i<array.length;i++) {
				rev ="";
				str = String.valueOf(array[i]);
				
				for(int j = str.length()-1;j>=0;j-- ) 
				{
					rev = rev + str.charAt(j);
				}
				reversedArray[i] = Integer.parseInt(rev);
		}
		Arrays.sort(reversedArray);
		for(int i: reversedArray)	
		System.out.println(i);
		}
}
