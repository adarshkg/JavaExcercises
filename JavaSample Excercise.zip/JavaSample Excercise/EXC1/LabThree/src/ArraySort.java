import java.util.Scanner;

public class ArraySort {

	public static void main(String[] args) {
	
		int[] array = new int[5];
		Scanner scan = new Scanner(System.in);
		System.out.println("Enter elements");
		for(int i =0;i<5;i++)
		{ 
			array[i] = scan.nextInt();
		}
		System.out.println(secondSmallest(array));
	}
		public static int secondSmallest(int [] array) {
		for(int j=0;j<array.length;j++)
		{
				for(int i=0;i<(array.length-1);i++) {
			
				if(array[i]>array[i+1]) 
				{
					int temp = array[i];
					array[i] = array[i+1];
					array[i+1] = temp;
			}
		  }
		}
		return array[1];
	}
}
