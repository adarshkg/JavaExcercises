package com.cg.jpademo.dao;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.Query;

import com.cg.jpademo.dto.Employee;
import com.cg.jpademo.util.DbUtil;

public class EmployeeDaoImpl implements EmployeeDao{

	EntityManager em;
	public EmployeeDaoImpl() {
		
		em=DbUtil.getConnection();
	}
	
	public void save(Employee emp) {
		em.persist(emp);
		em.getTransaction().commit();
	}

	public List<Employee> findBySalary(double low, double higher) {
		List<Employee> empList =  new ArrayList<Employee>();
		Query query = em.createQuery("FROM Employee WHERE salary BETWEEN :below AND :high");
		query.setParameter("below", low);
		query.setParameter("high", higher);
		empList = query.getResultList();
		return empList;
	}

	public List<Employee> findByDepartmentName(String name) {
	
			List<Employee> empList = new ArrayList<Employee>();
			Query query = em.createQuery("FROM Employee WHERE dept.name = :name");
			query.setParameter("name", name);
			empList = query.getResultList();
			
		return empList;
	}

}
