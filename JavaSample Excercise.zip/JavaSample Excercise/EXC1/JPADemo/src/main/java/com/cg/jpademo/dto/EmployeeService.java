//package com.cg.jpademo.dto;
//
//import java.util.Date;
//
//import javax.persistence.EntityManager;
//import javax.persistence.EntityManagerFactory;
//import javax.persistence.EntityTransaction;
//import javax.persistence.Persistence;
//
//import com.cg.jpademo.dto.Employee;
//
//public class EmployeeService {
//			private EntityManagerFactory emf=Persistence.createEntityManagerFactory("demoemployeemanagement");
//			private EntityManager em = emf.createEntityManager();
//			private EntityTransaction tx= em.getTransaction();
//			Address address = new Address();
//			public Employee createEmployee(int id, String name,double salary,boolean type,Date dateofJoining,Address address,Department department) {
//				Employee employeedb = new Employee();
//				employeedb.setId(id);
//				employeedb.setName(name);
//				employeedb.setSalary(salary);
//				employeedb.setType(type);
//				employeedb.setDateofJoining(dateofJoining);
//				employeedb.setAddr(address);
//				employeedb.setDept(department);
//					tx.begin();
//					em.persist(department);
//					em.persist(employeedb);
//					tx.commit();
//				return employeedb;
//			}
//			public Employee FindEmployee(int id) {
//				return em.find(Employee.class, id);
//			}
//			public void removeEmployee(int id) {
//				Employee employeedb= em.find(Employee.class, id);
//				if(employeedb!=null) {
//					tx.begin();
//					em.persist(employeedb);
//					tx.commit();
//				}
//			}
//			
//			public Employee updateEmployee(int id,double salary) {
//				Employee employeedb= em.find(Employee.class, id);
//				if(employeedb!=null) {
//					employeedb.setSalary(employeedb.getSalary() +salary);
//				}
//				return employeedb;
//}
//}
//
//
//
//
//
//
//
//
//
//
//
//
