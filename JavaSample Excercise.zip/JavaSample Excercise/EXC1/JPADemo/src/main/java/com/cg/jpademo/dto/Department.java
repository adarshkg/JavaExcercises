package com.cg.jpademo.dto;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.OneToMany;

@Entity
public class Department {
	@Id
	@Column(name="dep_id")
	private int id;
	@Column(name="dep_name")
	private String name;
	@OneToMany(mappedBy = "dept",cascade= CascadeType.ALL)
	private List<Employee> myEmployeeList = new ArrayList<Employee>();
 	
	public Department(int id, String name, List<Employee> myEmployeeList) {
		super();
		this.id = id;
		this.name = name;
		this.myEmployeeList = myEmployeeList;
	}
	public Department() {

	}
	
	public List<Employee> getMyEmployeeList() {
		return myEmployeeList;
	}
	public void setMyEmployeeList(List<Employee> myList) {
		this.myEmployeeList = myList;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	@Override
	public String toString() {
		return "Department [id=" + id + ", name=" + name + ", myEmployeeList=" + myEmployeeList + "]";
	}


}
