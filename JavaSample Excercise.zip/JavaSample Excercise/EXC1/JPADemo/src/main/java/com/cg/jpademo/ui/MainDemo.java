package com.cg.jpademo.ui;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Scanner;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

import com.cg.jpademo.dto.Address;
import com.cg.jpademo.dto.Department;
import com.cg.jpademo.dto.Employee;
import com.cg.jpademo.service.EmployeeServiceImpl;

public class MainDemo {
		public static void main(String[] args) { 
			
			
			Scanner scan = new Scanner(System.in);
			
			
//			System.out.println("Enter Employee Id");
//			int id = scan.nextInt();
//			System.out.println("Enter Name");
//			String name = scan.next();
//			System.out.println("Enter Salary");
//			double sal = scan.nextDouble();
//			System.out.println("Enter date of joining ");
//			String date = scan.next();
//			System.out.println("Enter Department Id ");
//			int did = scan.nextInt();
//			System.out.println("Enter Department name");
//			String dname = scan.next();
//			
//			
//			Address addr=new Address("Pune","Pune",12);
//			Department dep = new Department();
//			dep.setId(did);
//			dep.setName(dname);
//			
//			
//			
//			Employee emp = new Employee();
//			emp.setId(id);
//			emp.setName(name);
//			emp.setSalary(sal);
//			emp.setAddr(addr);
//			emp.setDateofJoining(new Date());
//			emp.setDept(dep);
//			
			EmployeeServiceImpl service = new EmployeeServiceImpl();
//			service.addEmployee(emp);
//			
//			
		List<Employee> myList = service.searchBySalary(1000, 30000);
			for (Employee employee : myList) {
				System.out.println("Employee Id "+employee.getId());
				System.out.println("Employee Name "+employee.getName());
				System.out.println("Employee Salary "+employee.getSalary());
				System.out.println("Employee Department Name "+employee.getDept().getName());
			}
		
			List<Employee> myListTwo = service.searchByDepartmentName("Python");
			for (Employee employee : myListTwo) {
				System.out.println("Employee Id "+employee.getId());
				System.out.println("Employee Name "+employee.getName());
				System.out.println("Employee Salary "+employee.getSalary());
				System.out.println("Employee Department Name "+employee.getDept().getName());
			}
		
			
			
		
		}
}