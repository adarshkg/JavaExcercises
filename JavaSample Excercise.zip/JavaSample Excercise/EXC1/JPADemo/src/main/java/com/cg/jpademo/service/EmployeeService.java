package com.cg.jpademo.service;

import java.util.List;

import com.cg.jpademo.dto.Employee;

public interface EmployeeService  {

	public void addEmployee(Employee emp);
	public List<Employee> searchBySalary(double low,double high);
	public List<Employee> searchByDepartmentName(String name);
}
