package com.cg.library.dto;

public abstract class Item {
		private long UIN;
		private String title;
		private int numberOfCopy;
		
		abstract void checkIn();
		abstract void checkOut();
		abstract void addItem();
		abstract void equals();
		abstract void print();

		
		public Item() {
			
		}
		
		
		public long getUIN() {
			return UIN;
		}
		public void setUIN(long uIN) {
			UIN = uIN;
		}
		
		
		public String getTitle() {
			return title;
		}
		public void setTitle(String title) {
			this.title = title;
		}
		
		
		public int getNumberOfCopy() {
			return numberOfCopy;
		}
		public void setNumberOfCopy(int numberOfCopy) {
			this.numberOfCopy = numberOfCopy;
		}


		@Override
		public String toString() {
			return "Item [UIN=" + UIN + ", title=" + title + ", numberOfCopy=" + numberOfCopy + "]";
		}
		
		
		
}
