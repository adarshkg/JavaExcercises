package com.cg.library.dto;

abstract class WrittenItem extends Item{
   private String author;

@Override
void checkIn() {
	// TODO Auto-generated method stub
	
}

@Override
void checkOut() {
	// TODO Auto-generated method stub
	
}

@Override
void addItem() {
	// TODO Auto-generated method stub
	
}

@Override
void equals() {
	// TODO Auto-generated method stub
	
}

@Override
void print() {
	// TODO Auto-generated method stub
	
}
}
