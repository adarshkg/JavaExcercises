package com.cg.library.dto;

public class Video extends MediaItem{
	     private String artist;
	     private String genre;
	     
}
