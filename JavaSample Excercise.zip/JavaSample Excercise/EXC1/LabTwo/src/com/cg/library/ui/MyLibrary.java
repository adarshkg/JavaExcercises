package com.cg.library.ui;

public class MyLibrary {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		System.out.println("LIBRARY MANAGEMENT SYSYTEM");
		System.out.println("");
		
		

	}

}
