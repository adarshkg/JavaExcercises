package com.cg.library.dto;

public class Book extends WrittenItem {

}
