package com.cg.library.dto;

public class JournalPaper extends WrittenItem {

	private int publishedYear;
}
