package com.cg.library.dto;

public class CD extends MediaItem{
     private String director;
     private String genre;
     private int year;
}
