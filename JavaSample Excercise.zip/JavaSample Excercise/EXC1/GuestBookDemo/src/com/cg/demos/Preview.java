package com.cg.demos;

import java.io.IOException;
import java.io.PrintWriter;

import javax.print.attribute.standard.PrinterLocation;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class Preview
 */
@WebServlet("/Preview")
public class Preview extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public Preview() {
        super();
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	
		String email=request.getParameter("email");
		Cookie userData[]= request.getCookies();
		String guestName = userData[0].getValue();
		
		PrintWriter out = response.getWriter();
		
		out.println("<html>");
		out.println("<head>");
		out.println("<title>Preview</title>");
		out.println("</head>");
		out.println("<body>");
		out.println("<p>Please confiem your information</p>");
		out.println("<p>GuestName :"+guestName+"</p>");
		out.println("<p>EmailId :"+email+"</p>");
		
		Cookie emailData = new Cookie("email", email);
		response.addCookie(emailData);
		
		out.println("<form name='frm' action='saveData' method='post'>");
		out.println("<p><input type='submit' value='Show Preview' name='btnPreview'/></p>");
		out.println("</form");
		out.println("</body>");
		out.println("</html>");
		
	}

}
