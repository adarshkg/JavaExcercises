import java.util.Scanner;

public class SumOfCubes {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int number;
		Scanner scan = new Scanner(System.in);
		System.out.println("enter the number");
		number = scan.nextInt();
		System.out.println(sumofcubes(number));
	}
	
	
 
	public static int sumofcubes(int number) {
	int remainder,cube=0;
	while(number!=0)
		
	{
	remainder = number%10;
	cube += remainder*remainder*remainder;
	number = number/10;
	}
	return cube;
}
}
