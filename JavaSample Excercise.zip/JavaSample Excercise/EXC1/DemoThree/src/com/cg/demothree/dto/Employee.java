package com.cg.demothree.dto;

import java.math.BigDecimal;

import javax.swing.plaf.basic.BasicIconFactory;

public class Employee {
	
	private int empId;
	public static double pf;
	private String employeeName;
	private BigDecimal empSalary;
	private double increment;
	
	public Employee(){
		
	}
	
	public Employee(int empId, String employeeName, BigDecimal empSalary, double increment) {
		super();
		this.empId = empId;
		this.pf = pf;
		this.employeeName = employeeName;
		this.empSalary = empSalary;
		this.increment = increment;
	}
	

	public int getEmpId() {
		return empId;
	}

	public void setEmpId(int empId) {
		this.empId = empId;
	}

	

	public String getEmployeeName() {
		return employeeName;
	}

	public void setEmployeeName(String employeeName) {
		this.employeeName = employeeName;
	}

	public BigDecimal getEmpSalary() {
		return empSalary;
	}

	public void setEmpSalary(BigDecimal empSalary) {
		this.empSalary = empSalary;
	}

	public double getIncrement() {
		return increment;
	}

	public void setIncrement(double increment) {
		this.increment = increment;
	}

	public BigDecimal takehomeSalary() {
		BigDecimal in = BigDecimal.valueOf(this.increment);
		BigDecimal pfa = BigDecimal.valueOf(this.pf);
		BigDecimal takeHomeSal= this.empSalary.add(this.empSalary.multiply(in)).subtract(pfa);
		return takeHomeSal;
	}
	public String getFullName() {
		return this.employeeName + " Capgemini";
	}
	
	@Override
	public String toString() {
		return "Employee [empId=" + empId + ", pf=" + pf + ", employeeName=" + employeeName + ", empSalary=" + empSalary
				+ ", increment=" + increment + "]";
	}

}
