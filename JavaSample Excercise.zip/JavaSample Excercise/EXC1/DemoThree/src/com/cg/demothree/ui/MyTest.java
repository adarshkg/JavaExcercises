package com.cg.demothree.ui;

import java.math.BigDecimal;

import com.cg.demothree.dto.Employee;

public class MyTest {
	double  salary =1000;
	
	public static void main(String[] args) {
		
		
	
		
		// System.out.println(salary); //Cannot make a static reference to the non-static field salary

		
		
		MyTest test = new MyTest();// variable accessing inside  a static method using Objetc
		System.out.println(test.salary);
		
		getAllData();
		//getData(); // Cannot make a static reference to the non-static method getData() from the type MyTest
		test.getData();
		
		
		
		
		
		Employee emp = new Employee(1001, "Adarsh",new BigDecimal(10000), 0.1);
		
		System.out.println("Employee Id: " +emp.getEmpId());
		System.out.println("Employee Name: " +emp.getFullName());
		System.out.println("Employee Salary " +emp.takehomeSalary());
		
		Employee.pf =1200;
		System.out.println("pf is "+Employee.pf);
		
		
		Employee emp2 = new Employee(1002, "Ad",new BigDecimal(12000), 0.2);

		System.out.println("Employee Id: " +emp2.getEmpId());
		System.out.println("Employee Name: " +emp2.getFullName());
		System.out.println("Employee Salary " +emp2.takehomeSalary());
		System.out.println("pf is "+Employee.pf);
//		System.out.println(empl.getEmpId());


	}
	
	
	static void getAllData() {
		//static
		System.out.println("static...");
	}
	void getData() {
		System.out.println("non static...");

	}
	

}
