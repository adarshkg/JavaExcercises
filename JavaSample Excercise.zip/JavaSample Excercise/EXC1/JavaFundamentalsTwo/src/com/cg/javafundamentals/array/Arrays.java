package com.cg.javafundamentals.array;

public class Arrays {

	public static void main(String[] args) {
		
		
		       double [] leftVals = {12.0d, 5.0d, 13.9d ,12.0d ,17.0d};
		       double [] rightVals = {22, 5.0d, 23.9d, 22.0d, 27.0d};
		       char [] opCode = {'b', 'c', 'd', 'a'};
		       double [] results = new double[opCode.length];
		      
		      
		      for(int i=0;i<opCode.length;i++) {
		    	 switch(opCode[i]){
		    	 case 'a': 
		    	 {
		    		  results[i] = leftVals[i] + rightVals[i];
		    		  break;
		    	  }
		    	 case'b':
		    	 {
		    		  results[i] = leftVals[i] - rightVals[i];
		    		  break;

				 }
		    	 case'c':
		    	 {
		    		  results[i] = leftVals[i] * rightVals[i];
		    		  break;

				}
		    	 case 'd':
		    	 {
		    		  results[i] = leftVals[i] / rightVals[i];
		    		  break;

				}
		    	 default:
		    	 {
		    		 System.out.println("error = Invalid input");
		    		 results[i] = 0.0d;
		    		 break;
		    	 }
		    	  
		      }
		      }
		      
		      for(int i =0;i<opCode.length;i++) {
		    	  System.out.println(results[i]);
		      }
		      
		      

	}

}
