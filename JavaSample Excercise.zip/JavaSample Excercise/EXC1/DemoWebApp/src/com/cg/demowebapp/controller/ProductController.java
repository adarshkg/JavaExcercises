package com.cg.demowebapp.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.cg.demowebapp.dto.Product;
import com.cg.demowebapp.service.ProductService;
import com.cg.demowebapp.service.ProductServiceImp;

/**
 * Servlet implementation class ProductController
 */
@WebServlet(urlPatterns= {"/add","/show","/addProduct","/search","/update","/delete","/deleteProduct","/searchid","/updateProduct"})
public class ProductController extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
	ProductService service;
    public ProductController() {
        super();
        service = new ProductServiceImp();
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {		
	
		doPost(request, response);
		
		
		
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String url = request.getServletPath();
		
		if(url.equals("/update")) {
			RequestDispatcher req = request.getRequestDispatcher("update.jsp");
			req.forward(request, response);
			String productId= request.getParameter("prodid");
		}
		if(url.equals("/updateProduct")) {
			
			RequestDispatcher req = request.getRequestDispatcher("updateProduct.jsp");
			req.forward(request, response);
			String productId= request.getParameter("prodid");
		}
		
		
		
		if(url.equals("/delete")) {
			RequestDispatcher req = request.getRequestDispatcher("delete.jsp");
			req.forward(request, response);
			String productId= request.getParameter("prodid");
		}
		if(url.equals("/deleteProduct")) {
			String productId= request.getParameter("prodid");
			service.deleteProduct(Integer.parseInt(productId));
			RequestDispatcher req = request.getRequestDispatcher("showProduct.jsp");
			req.forward(request, response);
			
		}
		
		
		
		if(url.equals("/search")) {

			RequestDispatcher req = request.getRequestDispatcher("searchProduct.jsp");
			req.forward(request, response);
			String productId= request.getParameter("prodid");
				
		}
		if(url.equals("/searchid")) {
			int productId = Integer.parseInt(request.getParameter("prodid"));
			Product product = service.searchProductById((productId));
			request.setAttribute("myprod", product);
			RequestDispatcher req = request.getRequestDispatcher("searchProduct.jsp");
			req.forward(request, response);
			
			
		}
		
		
		
		if(url.equals("/add")) {
//			addProduct.jsp
			RequestDispatcher req =request.getRequestDispatcher("AddProduct.jsp");
			req.forward(request, response);
		}
		
		if(url.equals("/addProduct")){
		
//		fetch the data from AddProduct.jsp
		String productId= request.getParameter("prodid");
		String productName= request.getParameter("prodname");
		String productPrice= request.getParameter("prodprice");
		String productOnline= request.getParameter("prodonline");
		String productCategory= request.getParameter("cato");
		
		Product prod =new Product();
		prod.setProdId(Integer.parseInt(productId));
		prod.setProdName(productName);
		prod.setPrice(Double.parseDouble(productPrice));
		prod.setOnline(productOnline);
		prod.setCategory(productCategory);
		service.addProduct(prod);
		
		RequestDispatcher req = request.getRequestDispatcher("productList.jsp");
		req.forward(request, response);
		
		
	
		}
		
		
		if(url.equals("/show")) {
			//showProduct.jsp
			
			List<Product> myList = service.showProduct();
			request.setAttribute("myprod", myList);
			
			RequestDispatcher req =request.getRequestDispatcher("showProduct.jsp");
			req.forward(request, response);
		}
	}

}
