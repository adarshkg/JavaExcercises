package com.cg.demowebapp.service;

import java.util.List;

import com.cg.demowebapp.dao.ProductRepository;
import com.cg.demowebapp.dao.ProductRepositoryImp;
import com.cg.demowebapp.dto.Product;

public class ProductServiceImp implements ProductService{

	ProductRepository repo;
	public ProductServiceImp() {
		repo= new ProductRepositoryImp();
	}
	
	@Override
	public void addProduct(Product prod) {
		repo.save(prod);
	}

	@Override
	public List<Product> showProduct() {
		return repo.showAll();
	}

	@Override
	public Product searchProductById(int id) {
		return repo.findById(id);
	}

	@Override
	public void deleteProduct(int id) {
		repo.delete(id);
		
	}




}
