package com.cg.demowebapp.dao;

import java.util.List;

import com.cg.demowebapp.dto.Product;

public interface ProductRepository {

	public void save(Product prod);
	public List<Product> showAll();
	public Product findById(int id);
	public void delete(int id);
	
}
