package com.cg.demowebapp.dao;

import java.util.LinkedList;
import java.util.List;

import com.cg.demowebapp.dto.Product;

public class ProductRepositoryImp  implements ProductRepository{

	List<Product> myList = new LinkedList<>();
	@Override
	public void save(Product prod) {
		Product pro =findById(prod.getProdId());
		if(pro==null){
		
				myList.add(prod);
		}
		else {
			pro.setProdId(prod.getProdId());
			pro.setProdName(pro.getProdName());
			pro.setPrice(prod.getPrice());
			pro.setCategory(prod.getCategory());
			pro.setOnline(prod.getOnline());
		}
		
		
	}

	@Override
	public List<Product> showAll() {
		return myList;
	}

	@Override
	public Product findById(int id) {
		
		for (Product product : myList) {
			if(product.getProdId()==id) {
				return product;
			}
		}
		return null;
	}

	@Override
	public void delete(int id) {

		
		for (Product product : myList) {
			if(product.getProdId()==id) {
				 myList.remove(product);
			}
		

	}

}
}
