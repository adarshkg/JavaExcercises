package com.cg.demowebapp.dto;

public class Product {

	private int prodId;
	private String prodName;
	private double price;
	private String online;
	private String category;
	public int getProdId() {
		return prodId;
	}
	public void setProdId(int prodId) {
		this.prodId = prodId;
	}
	public String getProdName() {
		return prodName;
	}
	public void setProdName(String prodName) {
		this.prodName = prodName;
	}
	public double getPrice() {
		return price;
	}
	public void setPrice(double price) {
		this.price = price;
	}
	public String getOnline() {
		return online;
	}
	public void setOnline(String online) {
		this.online = online;
	}
	public String getCategory() {
		return category;
	}
	public void setCategory(String category) {
		this.category = category;
	}
	public Product(int prodId, String prodName, double price, String online, String category) {
		super();
		this.prodId = prodId;
		this.prodName = prodName;
		this.price = price;
		this.online = online;
		this.category = category;
	}
	public Product() {
		super();
	}
	@Override
	public String toString() {
		return "Product [prodId=" + prodId + ", prodName=" + prodName + ", price=" + price + ", online=" + online
				+ ", category=" + category + "]";
	}
	
}
