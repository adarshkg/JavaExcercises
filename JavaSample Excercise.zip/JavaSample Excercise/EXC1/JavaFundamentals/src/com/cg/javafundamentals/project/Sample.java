package com.cg.javafundamentals.project;

public class Sample {

	public static void main(String[] args) {
//		int salary = 1_0_00_00_000;
//		System.out.println(salary);//java SE7
		int i= 7 | 2;
		System.out.println(i);
	}

}
