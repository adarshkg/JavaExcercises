package com.cg.javafundamentals.st;

public class Static {

	public static void main(String[] args) {
		
		System.out.println("in main");
		new A();
		new A();
		A.getAll();
	}
	static {
		System.out.println("in main static");
	}

}


//static block will run first
class A{
	static {
		System.out.println("in class A static block");
	}
	public A() {
		System.out.println("In A");
	}
	public static void getAll() {
		System.out.println("in clas A  static method");
	}
		
}



