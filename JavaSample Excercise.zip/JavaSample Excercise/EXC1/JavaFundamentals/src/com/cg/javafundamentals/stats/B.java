package com.cg.javafundamentals.stats;

public abstract class B
{
	static 
	{
		System.out.println("In A");
	}
//	static int x=50;

}
