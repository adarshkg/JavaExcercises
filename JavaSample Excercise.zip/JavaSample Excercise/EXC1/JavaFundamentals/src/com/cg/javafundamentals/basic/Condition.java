//Testing the conditional statements

package com.cg.javafundamentals.basic;

public class Condition {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int trueVal = 1;
		int falseVal = 0;
		
		//if the true value is greater than false value then the true value is getting printed
		int result = trueVal > falseVal ? trueVal: falseVal;
		System.out.println(result);
		
		
		if (trueVal==falseVal)
			System.out.println("equal");
		else
			System.out.println("not equal");
			
				
		

	}

}
