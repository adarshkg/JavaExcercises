package com.cg.javafundamentals.project;

public class Static {

}
