package com.cg.javafundamentals.ui;

public class MyTest {

	public static void main(String[] args) {
		 Timing temp = new DayShift();
		 System.out.println(temp.time);
		 temp.getLogin();
		 temp.getLogout();
		 temp.Company();

	}

}
