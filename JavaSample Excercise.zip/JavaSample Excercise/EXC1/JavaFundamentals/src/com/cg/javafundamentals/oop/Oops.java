package com.cg.javafundamentals.oop;

public class Oops {

	public static void main(String[] args) {
//		new A().getAll();
//		B temp = new B();
//		System.out.println(temp.a);
//		temp.getAll();
		
		
		A temp = new B();
		
	}

}



class A{
	int a =10;
	
//	public A() {
//		System.out.println("In class A..");
//	}
	
	public void getAll() {
		System.out.println("In A");
	}
//	private double getAll(int a) { //Overloading3
//		System.out.println("hi get all"+20);
//		return 1.0d;
//	}
}


class B extends A {
//	public B() {
//		
//		//		super();	
//		System.out.println("In class B..");
//	}
	int a=20;
	public void getAll() {
		System.out.println("In B");
	}

	
}