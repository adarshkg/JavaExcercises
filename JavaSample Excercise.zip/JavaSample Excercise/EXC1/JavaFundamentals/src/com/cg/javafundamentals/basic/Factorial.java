package com.cg.javafundamentals.basic;

public class Factorial {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		int fact = 1;
		int kValue = 6;
		
//		while(kValue>1) {
//			fact *= kValue;
//			kValue -= 1;
//			
//		}
//		
//		System.out.println(fact);
//	
	
		do {
			fact *=kValue; 
			kValue-=1;
		}
		while(kValue>1);
		System.out.println(fact);
		
		
	


}
}
