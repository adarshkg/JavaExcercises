package com.cg.javafundamentals.abstracts;

public abstract class Abstract {

	double timing = 9.5;
	public abstract void logIn();
	public abstract double logOut();

	
	public  String getCompany(){
		return "Capgemini";
	}

}
