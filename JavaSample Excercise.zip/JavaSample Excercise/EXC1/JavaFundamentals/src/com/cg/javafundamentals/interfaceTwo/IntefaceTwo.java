package com.cg.javafundamentals.interfaceTwo;

public class IntefaceTwo implements InterfaceSample {

	@Override
	public void getAllData() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void printAll() {
		// TODO Auto-generated method stub
		
	}
	
	
    public static void method() {
		
   } 

}
	