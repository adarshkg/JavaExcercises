package com.cg.javafundamentals.abstracts;

public class DayShift extends Abstract {

	@Override
	public void logIn() {
		// TODO Auto-generated method stub
		System.out.println("Hi in Login");
	}

	@Override
	public double logOut() {
		// TODO Auto-generated method stub
		return 12.4;
	}

}
