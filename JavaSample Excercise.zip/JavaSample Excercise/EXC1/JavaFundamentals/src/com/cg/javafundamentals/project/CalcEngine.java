//package com.cg.javafundamentals.project;
//
//public class CalcEngine {
//
//	public static void main(String[] args) {
//		// TODO Auto-generated method stub
////		double [] val1 = {12,2,12,3};
////		double[]  val2 = {21,22,33,32};
////		char [] opVals = {'b','a','c','d'};
////		double [] result= new double[opVals.length];
//		
//		MathEquation[] equation = new MathEquation[4];
//		equation[0] = new MathEquation();
//		
//		
//		
//		
//		
//		
//		
//		
//		
//		
//		
//		
//		
//		
//		
//		
//		
//		
//		
//		
//		
//		
//	}
//
//}
//		
//		
//		
//		
//		
//		
//		
//		
//		
////		if(opVals == 'a' )
////		{
////			result = val1 + val2;
////		    System.out.println(result);
////		}
////		else if(opVals == 's')
////		{
////			result =  val2 - val1;
////			System.out.println(result);
////		}
////		else
////			result = opVals=='b'?result*100:result/100;
////			System.out.println(result);
////		
////		
////	}
//
