package com.cg.javafundamentals.interfaces;

public interface D {
	
	public void setData();
	public void getMyName();
}
