package com.cg.javafundamentals.statics;


public class Static {

	public static void main(String[] args) {
		
		Flights.resetAllPassengers();
		
		System.out.println(Flights.getAllPassengers());
		
		Flights f1= new Flights();
		Flights f2= new Flights();
		//f1.add1Passenger();
		f1.add1Passenger();

		//f2.add1Passenger();
		f2.add1Passenger();


	}

}



class Flights{
	int passengers;
	
	void add1Passenger() {
		if(hasSeating()) {
			passengers+=1;
			allPassengers+=1;
			System.out.println("allpassengers "+allPassengers+" passengers: "+passengers);
		}
		else 
		{
			 handleTooMany();
		}
	}
	
	static int allPassengers;
	
	static int getAllPassengers() 
	{
	  return allPassengers;
	}
	
	static int resetAllPassengers()
	{
		return allPassengers =0;
	}
	
	public boolean hasSeating() {
		return passengers<=allPassengers;
	}
	public boolean handleTooMany() {
		return false;
		
	}
}
	