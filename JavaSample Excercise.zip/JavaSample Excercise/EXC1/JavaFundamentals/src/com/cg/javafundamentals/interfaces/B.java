package com.cg.javafundamentals.interfaces;

public interface B extends A {
	
	public void setData();


}
