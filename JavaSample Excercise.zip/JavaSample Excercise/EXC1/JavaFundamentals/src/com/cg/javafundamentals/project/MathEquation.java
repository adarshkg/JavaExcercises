//package com.cg.javafundamentals.project;
//
// class MathEquation {
//
////      public double val1;
////      public double val2;
////      public char opVals;
////      public double result;
//	
//	
//	
////        double [] leftVals = {12.0d, 5.0d, 13.9d ,12.0d ,17.0d};
////        double [] rightVals = {22.0d, 5.0d, 23.9d, 22.0d, 27.0d};
////        char [] opCode = {'b', 'c', 'd', 'a'};
////       
//      
//      
//      for(int i=0;i<opCode.length;i++) {
//    	  
//      }
//      
//      
////
////     public void execute() {
////    	  switch(opVals) {
////  		
////			case 'a':	
////				result =val1+val2;
////				break;
////			case 'b':
////				result =val1-val2;
////				break;
////			case 'c':
////				result =val1/val2;
////				break;
////			case 'd':
////				result =val1*val2;
////				break;
////			default:
////				System.out.println("error- invalid opcode");
////				result = 0.0d;
////				break;
////		}
////      }
//
//}
//}
