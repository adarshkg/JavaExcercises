package com.cg.javafundamentals.interfaces;

public class Interfaces implements A,B,D{
    public static void main(String[]args) 
    {
    }
    
    
	@Override
	public void getAllDAata() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void prinAllDAata() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void setData() {
		// TODO Auto-generated method stub
		
	}


	@Override
	public void getMyName() {
		// TODO Auto-generated method stub
		
	}
    
}
