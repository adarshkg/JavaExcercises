package com.cg.javafundamentals.string;

import java.awt.Window.Type;

public class StringClass {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		final int c = 10;
	
		Flight f1 = new Flight();
		System.out.println(f1);
		StringBuilder sb = new StringBuilder();
		String location = "London";
		
		sb.append(f1);
		System.out.println(sb);
		sb.append(location+" to");
		System.out.println(sb);
		
		int a=10;
		Integer b = Integer.valueOf(10);
		System.out.println(b);
		
		
		Integer d =12345678;
		Integer e =12345678;
		if(d==e)
			System.out.println("true");
		else
			System.out.println("false");

	}

}

class Flight
{
	int flightNumber;
	char flightClass='A';

	@Override
	public String toString() {
		if(flightNumber>0) {
			return "flight # " +flightNumber;
		}
		else
			return "flight # " +flightClass;

	}

}