package com.cg.javafundamentals.staticclass;

import com.cg.javafundamentals.staticclass.A.B;

public class StaticClass {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
//          B temp=new A().new B();//non static
		  B temp = new A.B();
          temp.getAl();
          
          A demo = new A();
          demo.getA();
	}

}


class A{
	private static int a=10;
	
	
	static  class B{
		
		static int b =20; 
		public void getAl() {
			System.out.println("inside class B " +a);
		}
		
	}
	public  void getA() {
		System.out.println("in class A ");
	}
	

}