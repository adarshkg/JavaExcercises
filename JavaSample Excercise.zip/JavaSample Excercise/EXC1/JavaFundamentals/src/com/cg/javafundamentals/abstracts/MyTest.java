package com.cg.javafundamentals.abstracts;

public class MyTest {

	public static void main(String[] args) {
      Abstract temp = new DayShift();
      temp.logIn();
      temp.logOut();
      temp.getCompany();
      System.out.println(temp.timing);
	}

}
