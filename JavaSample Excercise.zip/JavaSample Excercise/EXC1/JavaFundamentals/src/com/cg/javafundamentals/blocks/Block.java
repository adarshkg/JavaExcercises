package com.cg.javafundamentals.blocks;

public class Block {

	public static void main(String[]args) {
		
	}
	
	static
	{
		int a =10;
		System.out.println(a);

	}
	
}
