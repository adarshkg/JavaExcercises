package com.cg.javafundamentals.interfaces;

public interface A {
	
	public void getAllDAata();
	public void prinAllDAata();

}
