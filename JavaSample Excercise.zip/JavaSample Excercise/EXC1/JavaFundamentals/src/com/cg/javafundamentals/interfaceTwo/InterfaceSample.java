package com.cg.javafundamentals.interfaceTwo;

public interface InterfaceSample {
	
	public void getAllData();
	public void printAll();

	
	public static void method() {
		System.out.println("static print");
 } 
	public default void method2() {
		System.out.println("default print");
  }
}