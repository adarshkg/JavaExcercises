package com.cg.javafundamentals.stats;

public class Statics  {

	public static void main(String[] args) throws ClassNotFoundException 
	{
		System.out.println("In main");
//		B.x = 55;
		Class.forName("com.cg.javafundamentals.stats.B");

	}


}

