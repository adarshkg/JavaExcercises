package com.cg.javafundamentals.ui;

public class DayShift implements Timing{

	@Override
	public void getLogin() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void getLogout() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void Company() {
		// TODO Auto-generated method stub
		
	}

}
