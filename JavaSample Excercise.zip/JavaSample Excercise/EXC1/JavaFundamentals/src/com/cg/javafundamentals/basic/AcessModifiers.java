package com.cg.javafundamentals.basic;

    public class AcessModifiers {
    	private int passengers;
    	private int seats;
    	public AcessModifiers() {
    		seats = 150;
    		passengers = 0;
    	} 
    	
    	
	public void addPassegner() {
		if(passengers<seats) {
			passengers += 1;
			System.out.println(passengers);
		}
		else {
			tooMany();
		}
			
	}
	private void tooMany() {
		System.out.println("too may passengers");
	}
	
	
	public static void main(String[] args) {
		 AcessModifiers am = new AcessModifiers();
		 am.addPassegner();
		 am.addPassegner();

	}

}
