package com.cg.javafundamentals.ui;

public interface Timing {
	
	double time =9.5;//static finals (compiler thinking)
	
	public void getLogin();//These all classes are abstract classes
	public void getLogout();
	public void Company();

}
