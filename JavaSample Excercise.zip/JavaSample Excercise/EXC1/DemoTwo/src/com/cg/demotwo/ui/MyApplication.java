package com.cg.demotwo.ui;

import java.util.Scanner;

import com.cg.demotwo.dto.Account;
import com.cg.demotwo.dto.User;

public class MyApplication
{

	public static void main(String[] args) {
		
		int choice=0;
		int userId=0;
		String userName="";
		String address="";
		double balance=0;
		int accountNumber=0;
		

		Account account = new Account();
		User user = new User();
		
		
		do 
		{
			System.out.println("1.Add Customer \n 2.Exit");
		
		
			Scanner scan = new Scanner(System.in);
			System.out.println("enter your choice(1/2)");
			choice = scan. nextInt();
		 
			switch(choice) 
			{
				case 1:
			
					System.out.println("Enter userId");
					userId = scan. nextInt();

					System.out.println("Enter userName");
					userName = scan. next();

					System.out.println("Enter userAddress");
					address = scan. next();

					System.out.println("Enter Account balance");
					balance = scan. nextDouble();

					System.out.println("Enter Account number");
					accountNumber = scan. nextInt();
			
					account.setAccountBalance(balance);
					account.setAccountNumber(accountNumber);
				
					user.setUserId(userId);
					user.setUserName(userName);
					user.setUserAddress(address);
					user.setAccount(account);
					break;
			
				case 2:
			
					System.out.println("\n\nUsername is "+user.getUserName());
					System.out.println("Account Id is " + user.getAccount().getAccountNumber());
					System.out.println("Account balance is "+ user.getAccount().getAccountBalance());
					choice=0;
					break;
		
				default:
					
					System.out.println("wrong choices");
			}
			
		}while(choice!=0);
		
	}
}


