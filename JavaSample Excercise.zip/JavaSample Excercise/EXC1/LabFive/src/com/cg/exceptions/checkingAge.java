package com.cg.exceptions;

public class checkingAge {

	

	public static void main(String[] args) {
		int age =13;
		try {
			validateName(age);
		} catch (MyException e) {
			// TODO Auto-generated catch block
			System.out.println("Exception"+e);
		}
		System.out.println("rest of the code");
	}
	
	static void validateName(int age) throws MyException {
		if(age<15)
		{
			throw new MyException("Age  is invalid");
		}
		else {
			System.out.println("this is  a valid age");
		}
		
	}

}
