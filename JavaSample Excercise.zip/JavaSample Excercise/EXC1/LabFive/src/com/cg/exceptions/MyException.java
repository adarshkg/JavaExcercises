package com.cg.exceptions;

public class MyException extends Exception {
			
	 MyException(String s) {
			super(s);
	}

}
