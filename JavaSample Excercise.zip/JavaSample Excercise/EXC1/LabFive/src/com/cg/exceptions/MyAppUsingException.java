package com.cg.exceptions;

public class MyAppUsingException extends MyException {

	MyAppUsingException(String s) {
		super(s);
		// TODO Auto-generated constructor stub
	}

	public static void main(String[] args) {
		String firstName ="a";
		String lastName = "";
		try {
			validateName(firstName, lastName);
		} catch (MyException e) {
			// TODO Auto-generated catch block
			System.out.println("Exception"+e);
		}
		System.out.println("rest of the code");
	}
	
	static void validateName(String firstName,String lastName) throws MyException {
		if(firstName==""||lastName=="")
		{
			throw new MyException("Name is invalid");
		}
		else {
			System.out.println("this is  a valid name");
		}
		
	}

}
