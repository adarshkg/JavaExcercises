package com.cg.eis.exception;

public class EmployeeException {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
