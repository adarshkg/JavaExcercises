package com.cg.labfive;

import java.util.Scanner;

public class PrimeNumber {

	public static void main(String[] args) {
		System.out.println("Enter any Integer Number");
		Scanner scan = new Scanner(System.in);
		int n =  scan.nextInt();
		boolean flag=true;
		for(int i =2;i<n;i++) 
		{
			for(int j=2;j<i;j++) 
			{
				if(i%j==0) 
				{
					flag=false;
					break;
				}
				else 
				{
					flag =true;
				}
				
			}
			
			if(flag == true) {
				System.out.println(i);
			}
		
		}
	}

}
