package com.cg.labfive;

import java.util.Scanner;

public class FibonacciNonRecursive {

	public static void main(String[] args) {
		System.out.println("Enter any Integer Number");
		Scanner scan = new Scanner(System.in);
		int n =  scan.nextInt();
		System.out.println(fibonacci(n));
	}
	
	public static int fibonacci(int n) {
		
		int firstNum =0;
		int secondNumber =1;
		int thirdNum =0;
		
		for(int i=1;i<n;i++) {
			thirdNum = firstNum+secondNumber;
			firstNum = secondNumber;
			secondNumber =thirdNum;
		}
		return thirdNum;
	}

}
