package com.cg.labfive;

import java.util.Scanner;

public class Traffic {

	public static void main(String[] args) {
		Scanner scan = new Scanner(System.in);
		int a;
		do {
			
			 a = scan.nextInt();
		switch (a) {
		case 1:
			System.out.println("stop");
			break;
		case 2:
			System.out.println("ready");
			break;
		case 3:
			System.out.println("go");
			break;
		case 4:
//			
			break;
		default:
			break;
		}

	
	}while(a!=4);
	}

}
