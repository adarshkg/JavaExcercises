package com.cg.labfive;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.ObjectInput;
import java.io.ObjectInputStream;
import java.io.ObjectOutput;
import java.io.ObjectOutputStream;
import java.io.OutputStream;
import java.io.Reader;
import java.io.Writer;
import java.util.StringTokenizer;



public class MyFile {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Reader fileRead;
		Writer fileWrite;
		BufferedReader br=null;
		BufferedWriter bw=null;
		String data=null,str=null;
		try {
			fileRead=new FileReader("myread.txt");
			fileWrite=new FileWriter("mywrite.txt");
			br=new BufferedReader(fileRead);
			bw=new BufferedWriter(fileWrite);
			while((data=br.readLine())!=null) {
				if(data.length()>0 && data.contains(":")) {
				StringTokenizer st=new StringTokenizer(data, ":");
				 
				
				//StringTokenizer stOne=new StringTokenizer(data, " ");
			
				st.nextToken(":");
				str=st.nextToken(":");
				bw.write(str);
				bw.newLine();
				}
				else {
					bw.newLine();
				}
			}
		} catch (FileNotFoundException e) {
			System.out.println("File not found!");
			e.printStackTrace();
		} catch (IOException e) {
			System.out.println("Cant read file...");
		} finally {
			try {
				bw.close();
				br.close();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		
		}
		
		
		
		
	}

}

