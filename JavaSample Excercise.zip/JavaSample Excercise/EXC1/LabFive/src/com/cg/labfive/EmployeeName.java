package com.cg.labfive;

import java.util.Scanner;

public class EmployeeName {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("Enter any Integer Number");
		Scanner scan = new Scanner(System.in);
		System.out.println("Enter First Name");
		String firstName =  scan.next();
		System.out.println(firstName);
		System.out.println("Enter LastName");
		String lastName =  scan.next();
	}

}
