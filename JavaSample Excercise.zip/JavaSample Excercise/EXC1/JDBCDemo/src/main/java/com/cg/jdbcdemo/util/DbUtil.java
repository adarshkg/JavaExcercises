package com.cg.jdbcdemo.util;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Properties;

public class DbUtil {
	
	static Connection conn;

	public static Connection getConnetcion()  {
		Properties prop = new Properties();
		FileInputStream it;
		try {
			it = new FileInputStream("src/jdbc.properties");
			prop.load(it);

				if(prop!=null) {
							String driver = prop.getProperty("jdbc.driver");
							String url = prop.getProperty("jdbc.url");
							String uname = prop.getProperty("jdbc.username");
							String pass  =prop.getProperty("jdbc.password");
							Class.forName(driver);
							conn = DriverManager.getConnection(url, uname, pass);
				}

		}catch (SQLException e) {
			e.printStackTrace();
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		}
		
		return conn;
		
	}
}
