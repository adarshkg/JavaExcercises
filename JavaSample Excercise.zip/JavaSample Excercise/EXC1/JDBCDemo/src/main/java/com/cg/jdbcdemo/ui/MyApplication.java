package com.cg.jdbcdemo.ui;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Properties;
import java.util.Scanner;

public class MyApplication {

	public static void main(String[] args) {
		
		String driver,url,uname,upass;
		InputStream it =  null;
		try {
//			Class.forname();
			
			it = new FileInputStream("src/jdbc.properties");
			Properties prop = new Properties();
			prop.load(it);
			driver = prop.getProperty("jdbc.driver");
			url = prop.getProperty("jdbc.url");
			uname = prop.getProperty("jdbc.username");
			upass = prop.getProperty("jdbc.password");
			

			Class.forName(driver);
			Connection  conn = DriverManager.getConnection(url, uname, upass);

			
			
//			String insertsql ="insert into EMPLOYEE values(?,?,?)";
//			String selectsql = "delete from EMPLOYEE where emp_id=9";
			Scanner scan = new Scanner(System.in);
		
			System.out.println("enter the employee id to update");
			int ID =  scan.nextInt();
			
			String updatesql = "Update EMPLOYEE set emp_id="+ID+" where emp_id=100";
//			PreparedStatement pstm =conn.prepareStatement(insertsql);
			PreparedStatement pstm = conn.prepareStatement(updatesql);
			
			pstm.executeUpdate();
			
			
			
//			
//			while(result.next()) {
//				int id = result.getInt("emp_id");
//				String name = result.getString("emp_name");
//				double salary = result.getDouble("emp_salary");
//				
//				
//				System.out.println(id+"  "+name+"  "+salary);
//			}
			
//			System.out.println("enter the employee ");
//			String name =  scan.next();
//			System.out.println("enter the employee salary");
//			double salary =  scan.nextInt();
			
			//pstm.setInt(1, ID);
	
//			pstm.setString(2, name);
//			pstm.setDouble(3, salary);
			
//			pstm.executeUpdate();
			
			
			System.out.println("Connection established");
		} catch (SQLException e) {
			e.printStackTrace();
			System.out.println("Connection not happened");
		} catch (FileNotFoundException e) {

			e.printStackTrace();
		} catch (IOException e) {

			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		finally {
			try {
				it.close();
			} catch (IOException e) {
			
				e.printStackTrace();
			}
		}
	}

}
