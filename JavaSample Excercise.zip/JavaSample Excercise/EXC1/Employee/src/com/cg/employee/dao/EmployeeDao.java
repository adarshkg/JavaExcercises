package com.cg.employee.dao;

import java.sql.SQLException;
import java.util.List;

import com.cg.employee.exception.EmployeeException;
import com.cg.employee.pojo.Employee;

public interface EmployeeDao {
public Employee save(Employee emp) throws EmployeeException;
public List<Employee> findByName(String Name);
public Employee findById(int id) throws EmployeeException;
public List<Employee> showAll() throws SQLException;

}
