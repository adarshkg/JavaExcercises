package com.cg.employee.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.cg.employee.exception.EmployeeException;
import com.cg.employee.pojo.Employee;
import com.cg.employee.util.DBUtil;

public class EmployeeDaoImp implements EmployeeDao{
	PreparedStatement pstm;
	@Override

	public Employee save(Employee emp) throws EmployeeException {

		Connection conn = DBUtil.getConnetcion();
		String queryInsert = "INSERT INTO employee VALUES(?,?,?)";
		
		try {
			pstm = conn.prepareStatement(queryInsert);
			pstm.setInt(1, emp.getId());
			pstm.setString(2, emp.getName());
			pstm.setDouble(3, emp.getSalary());
			
			pstm.executeUpdate();
			
		} catch (SQLException e) {
		
			e.printStackTrace();
		}
		finally {
			try {
				pstm.close();
				conn.close();
			} catch (SQLException e) {

				e.printStackTrace();
				throw new EmployeeException("Connection not found");
			}
			
		}
		return emp;
	
		
	
	}
	

	@Override
	public List<Employee> findByName(String Name) {

		return null;
	}

	@Override
	public Employee findById(int id) throws EmployeeException {

		return null;
	}

	@Override
	public List<Employee> showAll() throws SQLException {
		Connection conn =DBUtil.getConnetcion();
		String query = "SELECT emp_id,emp_name,emp_salary FROM employee";
		PreparedStatement pstm;
		List<Employee> myList = new ArrayList<>();
		pstm = conn.prepareStatement(query);
		ResultSet result = pstm.executeQuery();
		
		
		while(result.next()) {
			Employee employee = new Employee();
			employee.setId(result.getInt("emp_id"));
			employee.setName(result.getString("emp_name"));
			employee.setSalary(result.getInt("emp_salary"));
			myList.add(employee);
		}
		
		return myList;
	}


}
