package com.cg.employee.service;

import java.sql.SQLException;
import java.util.List;

import com.cg.employee.exception.EmployeeException;
import com.cg.employee.pojo.Employee;

public interface IEmployeeService {
	
	public void addEmployee(Employee emp);
	public List<Employee> searchByName(String name);
	public Employee searchById(int id) throws EmployeeException;
	public List<Employee> showAll() throws SQLException;
	public Employee update(Employee emp);
	public void sort();
}
