package com.cg.employee.service;


import java.sql.SQLException;
import java.util.List;

import com.cg.employee.dao.EmployeeDao;
import com.cg.employee.dao.EmployeeDaoImp;
import com.cg.employee.exception.EmployeeException;
import com.cg.employee.pojo.Employee;



public class EmployeeService  implements IEmployeeService{
			EmployeeDao dao;
	 public EmployeeService() {
			
		 	dao = new EmployeeDaoImp();
	 }
	@Override
	public void addEmployee(Employee emp) {
		
		emp.setSalary(emp.getSalary()+(emp.getSalary()*10/100));
		try {
			dao.save(emp);
		} catch (EmployeeException e) {
			
			e.printStackTrace();
		}
	}	

	@Override
	public List<Employee> searchByName(String name) {
		
		return dao.findByName(name);
	}

	@Override
	public Employee searchById(int id) throws EmployeeException {
		
		return dao.findById(id);
	}

	@Override
	public List<Employee> showAll() throws SQLException {


		return dao.showAll();
	}

	@Override
	public Employee update(Employee emp) {
		
		return null;
	}

	@Override
	public void sort() {
	
		
	}
}

	
