package com.cg.employee.ui;

import java.sql.SQLException;
import java.util.List;
import java.util.Scanner;

import com.cg.employee.exception.EmployeeException;
import com.cg.employee.pojo.Employee;
import com.cg.employee.service.EmployeeService;
import com.cg.employee.service.IEmployeeService;

public class MyApplication {
	
	static IEmployeeService service;

	public MyApplication() {
		
	}
	public static void main(String[] args) {

		Scanner sc = new Scanner(System.in);
		service =  new EmployeeService();
		int choice =0;
		do {
			printDetails();
			System.out.println("Enter the choice");
			choice = sc.nextInt();
			switch (choice) {
			case 1:
				System.out.println("Enter employee ID");
				int id = sc.nextInt();
				System.out.println("Enter employee Name");
				String name = sc.next();
				System.out.println("Enter employee Salary");
				double salary = sc.nextDouble();
				
				Employee emp =  new Employee();
				emp.setId(id);
				emp.setName(name);
				emp.setSalary(salary);
				
				service.addEmployee(emp);
				break;
			case 2:
				List<Employee> myList;
				try {
					myList = service.showAll();
					for (Employee empData : myList)
					{
						System.out.println("Id is " +empData.getId());
						System.out.println("Name is " +empData.getName());
						System.out.println("Salary is " +empData.getSalary());	
					}
				} catch (SQLException e1) {

					e1.printStackTrace();
				}
				
				break;
			case 3:
				System.out.println("Enter the  employee id");
				int searchId = sc.nextInt();
				Employee empSearch = null;
				try {
					empSearch = service.searchById(searchId);
				} catch (EmployeeException e) {

					e.printStackTrace();
				}

				if(empSearch!=null)
				{
					
					System.out.println(empSearch);		
				}
				else 
				{
					System.out.println("Invalid user id");
				}
			
			
			case 4:
//				System.out.println("Enter the name employeee name");
//				String sname = sc.next();
//				List<Employee> empSearch = service.searchByName(sname);
//				for ( Employee empAll : empSearch) {
//					System.out.println("Id : " +empAll.getId());
//				}
				break;
				
			default:
				break;
			}
		}while(choice!=6);
	}
	public static void printDetails() {
		System.out.println("1.Add Employee");
		System.out.println("2.Show All Employee");
		System.out.println("3.Update Employee");
		System.out.println("4.Search Employee by Name");
		System.out.println("5.sort");
	}

}
