package com.cg.collections;

import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;

public class MyCollection {

	public static void main(String[] args) {
		List<String> myList = new LinkedList<String>();
		myList.add("C");
		myList.add("A");
		myList.add("A");
		
		
//		
//		List<Integer> myListOne = new LinkedList<Integer>();
//		myListOne.add("e");
//		myListOne.add(1);
//		myListOne.add(false);
//		
		
		
		for(String list:myList)
		{
		System.out.println(list);
		}
		
		System.out.println("----------------------------------------------");
		
		Iterator<String> it = myList.iterator();
		while(it.hasNext()) {
			System.out.println(it.next());
		}
	}

}
