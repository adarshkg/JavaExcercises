package com.cg.collections;

import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;

public class MyArrayList {
public static void main (String[] args) {
	List<String> myList = new LinkedList<String>();
	List<String> myList2 = new ArrayList<String>();
	myList.add("C");
	myList.add("A");
	myList.add("B");
	myList.add("A");
	System.out.println(myList.remove("A"));
	System.out.println(myList.set(2, "O"));
	System.out.println(myList.get(2));
	System.out.println(myList);

}
}
