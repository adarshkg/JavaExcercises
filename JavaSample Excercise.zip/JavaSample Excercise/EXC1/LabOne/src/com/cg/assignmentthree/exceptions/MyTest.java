package com.cg.assignmentthree.exceptions;

public class MyTest extends RuntimeException {

	public static void main(String[] args) {
		
		Employee emp =new Employee();
		emp.getAll(4000);
		
	}

}
