package com.cg.assignmentthree.natural;

import java.util.Scanner;

public class IncreasingNumber {
	
	
	public static void main(String[]args) 
	{
		Scanner scan = new Scanner(System.in);
		System.out.println("enter the number");
		int number = scan. nextInt();
		
		System.out.println(checkIfIncreasingNumber(number));	
		
	}
	
	public static boolean checkIfIncreasingNumber(int number) 
	
	{
		
		boolean bool = true;
		int lastVal;
		
		
		while(number!=0) 
		{
			lastVal = number%10;
			number =number/10;
			int nextVal = number%10;
			if(nextVal <= lastVal) 
			{
				bool =true;
			}
			else
			{
				bool= false;
				return bool;
			}
		}
		
	    return bool;

	}
}
