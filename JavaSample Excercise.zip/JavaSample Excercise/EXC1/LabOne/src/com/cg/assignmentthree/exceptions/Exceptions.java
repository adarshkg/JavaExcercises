package com.cg.assignmentthree.exceptions;

import java.io.IOException;

public class Exceptions extends RuntimeException {
		
			
	public Exceptions() {
		// TODO Auto-generated constructor stub
	}
	public Exceptions(String s){
		
	}
	
	
			
			
			
//			int a =10;
//			int b=0;
//			if(b==0) {
//				throw new IOException("errr   ");
//				
//			}
//			
//			
//			try {
//				
//			}catch(ArrayIndexOutOfBoundsException e) {
//				
//			}
//			
			
			
			
			
			
//			try 
//			{
//				System.out.println(a[3]);
//			}
//			catch (NullPointerException e)
//			{
//				System.out.println("Check...");
//			}
//			finally
//			{
////				always execute ,database will close
//				System.out.println("always...");
//			}
//			System.out.println("In B....");
//		}
		}


