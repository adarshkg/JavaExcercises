package com.cg.assignmentthree.natural;

import java.util.Scanner;

public class Power {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner scan = new Scanner(System.in);
		System.out.println("enter the number");
		int number = scan. nextInt();
		System.out.println(checkNumber(number));
		System.out.println();
	}
	
	
	public static boolean checkNumber(int n) {

	for(int i =0;i<n/2;i++) {
		if((Math.pow(2, i)== n))
		{
			return true;
		}
	}
	return false;
}
}
