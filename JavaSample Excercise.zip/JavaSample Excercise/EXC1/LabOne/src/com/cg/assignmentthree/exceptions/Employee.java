package com.cg.assignmentthree.exceptions;

public class Employee {

	public void getAll(int salary) /*throws ArrayIndexOutOfBoundsException*/
	{
	
		if(salary<=5000) {
			throw new Exceptions("employee salary should be above 5000");
		}
	System.out.println(salary);
		
		
}
}