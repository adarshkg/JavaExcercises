package com.cg.assignmentthree.natural;

import java.util.Scanner;

public class CalculateDiffOfSquares {
	public static void main(String[]args) 
	{
		
		Scanner scan = new Scanner(System.in);
		System.out.println("enter the number");
		int number = scan. nextInt();
		System.out.println(calculateDiff(number));
		
	}
	
	public static int calculateDiff(int n)
	{
		int individualSquare = 0;
		int wholeSquare = 0;
		int difference = 0;
		
		for(int i=1;i<=n;i++)
		{
			individualSquare += i*i;
			wholeSquare += i;
		}
		
		
		wholeSquare = wholeSquare * wholeSquare;
		difference =  individualSquare - wholeSquare;
		return difference;
	}
}
