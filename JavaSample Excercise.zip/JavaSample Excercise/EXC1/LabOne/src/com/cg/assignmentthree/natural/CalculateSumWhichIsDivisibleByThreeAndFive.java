package com.cg.assignmentthree.natural;

import java.util.Scanner;

public class CalculateSumWhichIsDivisibleByThreeAndFive {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner scan = new Scanner(System.in);
		System.out.println("enter the number");
		int number = scan. nextInt();
		System.out.println(calculateSum(number));
	}
	
	
	public static int calculateSum(int n) {
		int sum=0;
		for(int i=1;i<=n;i++) {
		if(i%3==0 || i%5==0) {
			sum += i;
			
		}
		}
		
		return sum;
	}

}
